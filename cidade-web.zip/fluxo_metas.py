"""Navegação e retorno pedagógico da campanha, sem dependência gráfica."""
from campanha import METAS, perguntas

def proxima_meta(eco):
 return next((i for i in range(len(METAS)) if i not in eco.concluidas()),None)

def pendentes(eco,i):
 return [j for j in range(len(perguntas(i,eco.estado['nivel']))) if j not in eco.respondidas(i)]

def primeiro_calculo(eco,i):
 return next(iter(pendentes(eco,i)),0)

def confirmar(eco,i,j,texto):
 """Registra somente uma resposta ainda não acertada; informa o novo progresso."""
 if j in eco.respondidas(i): return True,'Já registrado. Nenhum XP extra.'
 if not texto.strip(): return False,'Digite uma resposta numérica antes de confirmar.'
 antes=eco.estado['xp']; ok,exp=eco.resposta(i,j,texto); p=eco.progresso(i)
 if not ok: return False,'RESPOSTA INCORRETA. Dica: '+DICAS[i][j]
 msg=f'RESPOSTA CORRETA! +{eco.estado["xp"]-antes} XP. '+exp
 if p['concluida']: msg+=' Meta concluída! Avance para a próxima.'
 elif p['acertos']==p['total']: msg+=' Todos os cálculos registrados. Falta: '+METAS[i][3]
 else: msg+=f' Progresso: {p["acertos"]}/{p["total"]} cálculos.'
 return True,msg

def continuar(eco,i,j):
 """Destino após o feedback: próxima questão, pendência de ação ou próxima meta."""
 restantes=pendentes(eco,i)
 if restantes: return ('questao',i,next((k for k in restantes if k>j),restantes[0]))
 if not eco.progresso(i)['concluida']: return ('meta_pendente',i,j)
 prox=proxima_meta(eco)
 if prox is None: return ('metas',i,j)
 return ('questao' if pendentes(eco,prox) else 'meta_pendente',prox,primeiro_calculo(eco,prox))

# Dicas de método, na mesma ordem das questões EF e da questão extra EM.
DICAS=(
 ('Multiplique horas pelo valor de uma hora.','Multiplique horas pelo valor de uma hora.','Divida o salário pelas horas trabalhadas.','Calcule o bruto e multiplique por 1 menos a taxa de contribuição.'),
 ('Divida aluguel pela renda e multiplique por 100.','Subtraia o aluguel da renda.','Distribua o custo total de três aluguéis pelos três meses.','Multiplique o aluguel por 1 mais a taxa de reajuste.'),
 ('Converta 20% em decimal e multiplique pelo preço.','Subtraia o valor do desconto do preço inicial.','Divida o preço total pela quantidade.','Aplique cada desconto ao saldo que restou do anterior.'),
 ('Multiplique o orçamento pela fração destinada à alimentação.','Subtraia os dois gastos do orçamento.','Subtraia a sobra do preço do desejo.','Subtraia as duas porcentagens de 100% e aplique à renda.'),
 ('Multiplique a renda pela taxa de 10%.','Multiplique o valor mensal pelo número de meses.','Subtraia o imprevisto da reserva.','Multiplique a despesa mensal pelo número de meses.'),
 ('Multiplique o valor de uma parcela pela quantidade.','Subtraia o preço à vista do preço parcelado.','Divida a diferença pelo preço à vista e multiplique por 100.','Divida o acréscimo pelo preço inicial e multiplique por 100.'),
 ('Subtraia despesas de receitas.','Divida a sobra pela renda e multiplique por 100.','Subtraia a nova despesa da sobra anterior.','Reajuste os gastos antes de subtraí-los da renda.'),
 ('Multiplique a dívida pela taxa de juros.','Some os juros ao saldo inicial.','Subtraia a fatura do saldo da carteira.','Use capital × (1 + taxa) elevado ao número de meses; arredonde ao centavo.'),
 ('Use capital × taxa × tempo para os juros simples.','Use capital × (1 + taxa) elevado ao número de meses.','Calcule os dois montantes e subtraia.','Use capital × (1 + taxa) elevado ao número de meses; arredonde ao centavo.'),
 ('Multiplique o capital pela taxa mensal.','Some o rendimento ao capital.','Multiplique o capital pelo fator mensal duas vezes.','Eleve o fator mensal à terceira potência e arredonde ao centavo.'),
 ('Multiplique o preço por 1 mais a inflação.','Aplique o fator de inflação em cada mês.','Subtraia o novo preço do dinheiro disponível.','Aplique o fator mensal três vezes e arredonde ao centavo.'),
 ('Multiplique o salário por 1 mais a taxa de aumento.','Multiplique o novo valor por hora pela jornada.','Divida o aumento pelo salário antigo e multiplique por 100.','Reajuste o valor por hora antes de multiplicar pelas horas.'),
 ('Multiplique quantidade pelo custo unitário.','Multiplique a quantidade vendida pelo preço.','Subtraia o custo da receita.','Calcule a margem bruta em reais e subtraia o custo fixo.'),
 ('Subtraia o custo da receita.','Divida o lucro pela receita e multiplique por 100.','Subtraia o custo do ajudante do lucro bruto.','Divida o custo fixo pela diferença entre preço e custo unitário.'),
 ('Some os ativos e subtraia a dívida.','Divida a reserva pelo patrimônio e multiplique por 100.','Multiplique o patrimônio por 1 mais a taxa de aumento.','Use capital × (1 + taxa) elevado ao número de meses; arredonde ao centavo.'),
)
