import asyncio, base64, os, sys, time, json, traceback
from pathlib import Path
from js import window, document
from pyodide.ffi import to_js

save=Path('/cidade_save'); save.mkdir(exist_ok=True)
os.environ['CIDADE_SAVE_DIR']=str(save)
prefix='cidade-financeira:v10:'
profiles=['cidade_v3.sqlite3','cidade_v3_perfil2.sqlite3','cidade_v3_perfil3.sqlite3']
# Each browser has its own three local profiles. Never send saves to a server.
last={}; storage_ok=True
try:
    for name in profiles:
        data=window.localStorage.getItem(prefix+name)
        if data:
            raw=base64.b64decode(str(data),validate=True)
            if raw.startswith(b'SQLite format 3\x00'):
                (save/name).write_bytes(raw); last[name]=raw
except Exception:
    storage_ok=False
import main as game
import pygame as pg
KEYS={name:getattr(pg,'K_'+name) for name in ('UP','DOWN','LEFT','RIGHT','e','m','f','g','n','o','p','ESCAPE','RETURN','BACKSPACE','TAB','F2','F3','F4','F5','F6','F7','F8','F9','F10','F12')}

def store():
    global storage_ok
    try:
        for path in save.glob('*.sqlite3'):
            if path.name not in profiles: continue
            if Path(str(path)+'-journal').exists() or Path(str(path)+'-wal').exists(): continue
            raw=path.read_bytes()
            if last.get(path.name)!=raw:
                window.localStorage.setItem(prefix+path.name,base64.b64encode(raw).decode('ascii'))
                last[path.name]=raw
        storage_ok=True
    except Exception:
        storage_ok=False
    document.getElementById('save-status').textContent='Progresso salvo neste navegador' if storage_ok else 'Atenção: armazenamento local indisponível'

async def run():
    document.getElementById('status').textContent='Jogo pronto — clique na cidade para ativar o teclado.'
    game.musica()
    before=time.monotonic(); saved=0
    while game.running:
        now=time.monotonic(); dt=max(0,min(now-before,.04)); before=now
        controls=json.loads(str(window.cfReadControls()))
        game.web_keys={KEYS[k] for k in controls['held'] if k in KEYS}
        for name in controls['pressed']:
            if name in KEYS: pg.event.post(pg.event.Event(pg.KEYDOWN,key=KEYS[name],unicode=''))
        for text in controls['text']:
            # Allow the phone keyboard to enter the character name or a calculation.
            if game.view in ('personagem','questao','mini_jogo','distrito_calculo') or game.desafio:
                for _ in range(30): pg.event.post(pg.event.Event(pg.KEYDOWN,key=pg.K_BACKSPACE,unicode=''))
                for char in text[:24]:
                    pg.event.post(pg.event.Event(pg.KEYDOWN,key=0,unicode=char))
        game.frame(dt)
        if now-saved>.45: store(); saved=now
        await asyncio.sleep(1/60)
    store(); game.eco.db.close(); pg.quit()
    document.getElementById('status').textContent='Jogo encerrado. Atualize a página para recomeçar.'
