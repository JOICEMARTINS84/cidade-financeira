"""Distrito de patrimônio: valores fictícios em centavos, ações com cálculo obrigatório."""
from dataclasses import dataclass
from campanha import correto

COLUNAS={k:'INTEGER NOT NULL DEFAULT 0' for k in ('notebook','moveis','imovel','imovel_parcelas','carro','acoes','empresa_ampliada','roupa','roupa_equipada')}
AREAS=(('shopping','Shopping','Consumo e descontos'),('imobiliaria','Imobiliária','Financiamento e patrimônio'),('concessionaria','Concessionária','Transporte e manutenção'),('empresa_nova','Empreendedorismo','Expansão do quiosque'),('bolsa','Bolsa de valores','Risco e variação de preço'),('personal','Personalização','Necessidade e desejo'))
PRECOS=(1000,1100,900,1250,1050,800,1150)
IMOVEL=1200000
ENTRADA=300000
PARCELA=165000
CARRO=540000
MANUTENCAO=12000

def preco(dia): return PRECOS[((dia-1)//7)%len(PRECOS)]
def ativos(s): return s['imovel']*IMOVEL+s['carro']*CARRO+s['acoes']*preco(s['dia'])
def debito(s): return s['imovel_parcelas']*PARCELA

def brl(v): return 'R$ '+f'{v/100:,.2f}'.replace(',','X').replace('.',',').replace('X','.')

@dataclass(frozen=True)
class Acao:
 id:str
 titulo:str
 detalhe:str
 pergunta:str
 resposta:str
 explicacao:str
 habilitada:bool=True
 motivo:str=''

def opcoes(area,s):
 p=preco(s['dia']); q=s['acoes']; v=10*p
 if area=='shopping': return [
  Acao('notebook','Comprar notebook','De R$ 800 por R$ 680','Quanto custa após desconto de 15% sobre R$ 800?','680','800 − 120 = 680.',not s['notebook'],'Você já possui o notebook.'),
  Acao('moveis','Comprar móveis','3 itens de R$ 120, R$ 130 e R$ 100','Qual é o custo total dos três móveis?','350','120 + 130 + 100 = 350.',not s['moveis'],'Você já possui os móveis.')]
 if area=='imobiliaria': return [
  Acao('imovel_vista','Comprar imóvel à vista','R$ 12.000 • imóvel adicional; aluguel atual continua','Qual o valor de 20% de R$ 12.000?','2400','12.000 × 0,20 = 2.400.',not s['imovel'],'Você já possui um imóvel.'),
  Acao('imovel_prazo','Financiar imóvel','R$ 3.000 de entrada + 6 × R$ 1.650 mensais','Qual o total pago, incluindo entrada e parcelas?','12900','3.000 + 6 × 1.650 = 12.900.',not s['imovel'],'Você já possui um imóvel.'),
  Acao('imovel_quitar','Quitar parcelas restantes',f'{brl(debito(s))} • sem desconto fictício',f'Quanto custam {s["imovel_parcelas"]} parcelas de R$ 1.650?',str(debito(s)//100),'Número de parcelas × 1.650.',bool(s['imovel_parcelas']),'Não há parcelas pendentes.')]
 if area=='concessionaria': return [
  Acao('carro','Comprar carro à vista','R$ 5.400 • manutenção R$ 120 a cada virada de mês','Quanto é 12 × R$ 120 em manutenção anual?','1440','12 × 120 = 1.440.',not s['carro'],'Você já possui um carro.'),
  Acao('carro_vender','Vender carro','Receba R$ 5.400 (valor fixo fictício)','Quanto é 10% de R$ 5.400?','540','5.400 × 0,10 = 540.',bool(s['carro']),'Você não possui carro.')]
 if area=='empresa_nova': return [
  Acao('ampliar','Ampliar o quiosque','R$ 900 • +3 unidades de procura por dia','Se o lucro adicional for R$ 45/dia, em quantos dias recupera R$ 900?','20','900 ÷ 45 = 20 dias; lucro adicional é uma hipótese.',bool(s['negocio']) and not s['empresa_ampliada'],'Abra um quiosque primeiro ou a expansão já foi feita.')]
 if area=='bolsa': return [
  Acao('acoes_comprar','Comprar 10 cotas fictícias',f'{brl(p)}/cota • total {brl(v)}',f'Quanto custam 10 cotas de {brl(p)}?',str(v/100),'10 × preço unitário. O preço pode cair.',q<990,'Limite de cotas atingido.'),
  Acao('acoes_vender','Vender 10 cotas fictícias',f'{brl(p)}/cota • recebe {brl(v)}',f'Quanto recebe pela venda de 10 cotas de {brl(p)}?',str(v/100),'10 × preço unitário; receita não é necessariamente lucro.',q>=10,'São necessárias 10 cotas.')]
 if area=='personal': return [
  Acao('roupa','Comprar roupa verde','R$ 90 • item de personalização','Uma roupa de R$ 120 tem desconto de 25%. Qual o preço final?','90','120 × 0,75 = 90.',not s['roupa'],'Você já possui essa roupa.'),
  Acao('vestir','Vestir / trocar roupa','Sem custo • alterna roupa verde e original','Se a troca não tem custo, quanto sai da carteira?','0','Trocar uma roupa que já possui não gera despesa.',bool(s['roupa']),'Compre a roupa primeiro.')]
 return []

def concluida(area,s):
 return {'shopping':bool(s['notebook'] and s['moveis']),'imobiliaria':bool(s['imovel']),'concessionaria':bool(s['carro']),'empresa_nova':bool(s['empresa_ampliada']),'bolsa':s['acoes']>=10,'personal':bool(s['roupa'] and s['roupa_equipada'])}[area]

def aplicar(area,id,texto,s):
 """Retorna novo estado, mensagem e movimento de caixa; não altera entrada."""
 a=next((a for a in opcoes(area,s) if a.id==id),None)
 if not a: return False,'Ação indisponível.',s,0
 if not a.habilitada: return False,a.motivo,s,0
 if not correto(texto,a.resposta): return False,'RESPOSTA INCORRETA. '+a.explicacao,s,0
 n=s.copy(); custo=0
 if id=='notebook': n['notebook']=1; custo=68000
 elif id=='moveis': n['moveis']=1; custo=35000
 elif id=='imovel_vista': n['imovel']=1; custo=IMOVEL
 elif id=='imovel_prazo': n['imovel']=1; n['imovel_parcelas']=6; custo=ENTRADA
 elif id=='imovel_quitar': custo=debito(s); n['imovel_parcelas']=0
 elif id=='carro': n['carro']=1; custo=CARRO
 elif id=='carro_vender': n['carro']=0; custo=-CARRO
 elif id=='ampliar': n['empresa_ampliada']=1; custo=90000
 elif id=='acoes_comprar': n['acoes']+=10; custo=10*preco(s['dia'])
 elif id=='acoes_vender': n['acoes']-=10; custo=-10*preco(s['dia'])
 elif id=='roupa': n['roupa']=1; custo=9000
 elif id=='vestir': n['roupa_equipada']=1-s['roupa_equipada']
 if custo>s['saldo']: return False,'Cálculo correto, mas saldo insuficiente. Nenhuma compra feita.',s,0
 n['saldo']-=custo
 return True,'RESPOSTA CORRETA! '+a.explicacao+' Ação realizada.',n,-custo

def virada(s):
 """Cobrança mensal; falta de caixa vira conta aberta, sem saldo negativo."""
 movimentos=[]
 if s['imovel_parcelas']:
  s['imovel_parcelas']-=1; movimentos.append(('Imóvel: parcela',PARCELA))
 if s['carro']: movimentos.append(('Carro: manutenção',MANUTENCAO))
 for _,v in movimentos:
  pago=min(s['saldo'],v); s['saldo']-=pago; s['contas']+=v-pago
 return movimentos
