"""Projeção dimétrica ortográfica; coordenadas lógicas da V5 preservadas."""
import math
W,H=1100,700
# A base lógica continua em x/y; z é exclusivamente visual.
A,B,C,D=.76,-.47,.19,.48
OX,OY=550,405
CX,CY=550,350

def project(x,y,z=0):
 return (OX+A*(x-CX)+B*(y-CY), OY+C*(x-CX)+D*(y-CY)-z)

def unproject(x,y):
 x-=OX; y-=OY; det=A*D-B*C
 return (CX+(D*x-B*y)/det,CY+(-C*x+A*y)/det)

def direction(dx,dy):
 return ((D*dx-B*dy)/(A*D-B*C),(-C*dx+A*dy)/(A*D-B*C))

def depth(x,y): return project(x,y)[1]

LOTS={
 'casa':(52,138,206,132), 'mercado':(404,134,210,140),
 'empresa':(803,100,174,174), 'banco':(77,418,154,148),
 'loja':(752,438,276,128), 'negocio':(524,450,82,70),
}
DOORS={'casa':(154,282),'mercado':(508,285),'empresa':(890,285),'banco':(154,578),'loja':(890,578),'negocio':(575,531)}
