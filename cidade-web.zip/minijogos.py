"""Dezoito laboratórios de decisão: regras puras, sem Pygame. Valores fictícios."""
from campanha import correto
from dataclasses import dataclass

@dataclass(frozen=True)
class Jogo:
 id: str
 local: str
 titulo: str
 contexto: str
 cartas: tuple
 escolha: tuple
 pergunta: str
 resposta: str
 explicacao: str
 unidade: str='R$'

JOGOS=(
 Jogo('casa_orc','casa','Organize o mês','Você tem R$ 700. Selecione apenas as despesas essenciais que precisa pagar neste cenário.',(('Aluguel','R$ 450'),('Alimentação','R$ 180'),('Fone novo','R$ 110'),('Streaming','R$ 40')),(0,1),'Quanto sobra dos R$ 700 após pagar as despesas essenciais?','70','700 − (450 + 180) = 70. A sobra pode reforçar a reserva.'),
 Jogo('casa_res','casa','Semana de imprevistos','Uma emergência custa R$ 220. Você tem R$ 80 na carteira e R$ 200 de reserva. Selecione as duas fontes que cobrem o custo sem dívida.',(('Carteira','R$ 80'),('Reserva','Até R$ 200'),('Cartão','5% a.m.'),('Empréstimo','4% a.m.')),(0,1),'Usando primeiro toda a carteira, quanto resta na reserva?','60','220 − 80 = 140 da reserva; 200 − 140 = 60.'),
 Jogo('merc_cesta','mercado','Carrinho econômico','Monte uma compra com exatamente 2 kg de arroz e 1 kg de feijão pelo menor custo. Cada cartão pode ser usado uma vez.',(('Arroz 2 kg','R$ 12'),('Arroz 1 kg','R$ 7'),('Feijão 1 kg','R$ 9'),('Feijão 1 kg premium','R$ 13')),(0,2),'Qual é o total do carrinho escolhido?','21','12 + 9 = 21. Compare quantidade e preço, não apenas a embalagem.'),
 Jogo('merc_oferta','mercado','Caça às ofertas','Todos os pacotes têm a mesma quantidade e qualidade. Selecione o que tem menor preço final.',(('Pacote A','R$ 80, menos 25%'),('Pacote B','R$ 70, menos 10%'),('Pacote C','R$ 65, sem desconto'),('Pacote D','R$ 90, menos 20%')),(0,),'Qual é o preço final do pacote vencedor?','60','A: 80 × 0,75 = 60; B: 63; C: 65; D: 72.'),
 Jogo('emp_turno','empresa','Monte sua jornada','Você tem 8 horas. Selecione exatamente dois turnos que somem 8h e maximizem o salário bruto.',(('Turno A','4h × R$ 65/h'),('Turno B','4h × R$ 55/h'),('Turno C','4h × R$ 75/h'),('Turno D','2h × R$ 80/h')),(0,2),'Quanto você receberá pelos dois turnos?','560','4 × 65 + 4 × 75 = 560. Considere tempo e remuneração.'),
 Jogo('emp_contas','empresa','Auditoria de notas','O orçamento de material é R$ 300. Compre exatamente 3 caixas de papel e 2 toners escolhendo as notas de menor custo.',(('3 caixas papel','R$ 120'),('2 toners','R$ 140'),('3 caixas premium','R$ 150'),('2 toners premium','R$ 180')),(0,1),'Quanto ficará disponível no orçamento?','40','300 − (120 + 140) = 40. Conferir notas evita desperdício.'),
 Jogo('bank_inv','banco','Carteira de investimentos','Você investirá R$ 1.000 em um produto durante um mês. Neste modelo todos têm mesmo risco e liquidez. Escolha o maior rendimento líquido.',(('Poupança fictícia','1% a.m.'),('CDB fictício','1,5% a.m.'),('Conta sem rendimento','0% a.m.'),('Aplicação D','0,8% a.m.')),(1,),'Qual será o saldo após um mês?','1015','1.000 × 1,015 = 1.015. Na vida real, compare risco, impostos e liquidez.'),
 Jogo('bank_juros','banco','Fuja dos juros','Você precisa de R$ 500 por dois meses, sem amortizações, e todos os planos têm as mesmas demais condições. Escolha o menor total.',(('Plano A','4% a.m. simples'),('Plano B','4% a.m. composto'),('Plano C','5% a.m. simples'),('Plano D','5% a.m. composto')),(0,),'Qual será o total a pagar no plano escolhido?','540','500 × (1 + 0,04 × 2) = 540. Com juros compostos a 4%, seria 540,80.'),
 Jogo('loja_bike','loja','Pedale sem dívida','Você tem R$ 500 e deve manter pelo menos R$ 100 em caixa. Selecione o plano de menor custo total que respeita a reserva.',(('À vista','R$ 320'),('4 parcelas','4 × R$ 110'),('5 parcelas','5 × R$ 93'),('À vista premium','R$ 430')),(0,),'Quanto sobrará na carteira após a compra escolhida?','180','500 − 320 = 180. O menor custo total também preserva os R$ 100.'),
 Jogo('loja_parc','loja','Parcelas sob controle','O cliente só pode pagar R$ 100 por mês e não tem entrada. Entre os planos sem entrada que cabem no mês, escolha o menor total.',(('Plano A','4 × R$ 110'),('Plano B','5 × R$ 96'),('Plano C','6 × R$ 85'),('Plano D','8 × R$ 68')),(1,),'Quanto o cliente pagará ao final das parcelas?','480','5 × 96 = 480. A menor parcela não significa menor custo total.'),
 Jogo('quiosque_est','negocio','Escolha o fornecedor','Você precisa de exatamente 10 unidades de um produto idêntico. Escolha o lote com menor custo, incluindo frete.',(('Fornecedor A','10 × R$ 6 + R$ 10'),('Fornecedor B','10 × R$ 5,50 + R$ 8'),('Fornecedor C','10 × R$ 6,20 + R$ 5'),('Fornecedor D','10 × R$ 5,80 + R$ 12')),(1,),'Quanto custa o lote vencedor, com frete?','63','10 × 5,50 + 8 = 63. Inclua o frete no custo de aquisição.'),
 Jogo('quiosque_luc','negocio','Preço e procura','Cada lanche custa R$ 6. Estoque suficiente, sem outros custos. Escolha o preço que maximiza o lucro bruto previsto.',(('Preço A: R$ 10','Venda 9 unidades'),('Preço B: R$ 12','Venda 7 unidades'),('Preço C: R$ 15','Venda 4 unidades'),('Preço D: R$ 18','Venda 3 unidades')),(1,),'Qual é o lucro bruto na estratégia escolhida?','42','A: R$ 36; B: R$ 42; C: R$ 36; D: R$ 36. Em B: (12 − 6) × 7 = 42.'),
 Jogo('casa_contas','casa','Conta de luz','Seu orçamento de energia é R$ 130. Escolha o plano que usa até esse valor e tem menor custo total.',(('Plano A','R$ 95 + R$ 20'),('Plano B','R$ 90 + R$ 35'),('Plano C','R$ 100 + R$ 40'),('Plano D','R$ 105 + R$ 15')),(0,),'Quanto sobra do orçamento com o plano vencedor?','15','130 − (95 + 20) = 15. Some todas as cobranças antes de decidir.'),
 Jogo('merc_unit','mercado','Preço por litro','Compare quatro embalagens do mesmo suco. Escolha aquela com menor preço por litro.',(('1 litro','R$ 7,50'),('2 litros','R$ 13,00'),('3 litros','R$ 21,00'),('4 litros','R$ 28,00')),(1,),'Qual é o preço por litro da embalagem vencedora?','6.5','13 ÷ 2 = R$ 6,50 por litro. Compare o preço por unidade.'),
 Jogo('emp_extra','empresa','Hora extra','Para um trabalho de 4 horas, escolha a proposta com maior pagamento bruto. Horas extras: valor normal × 1,5.',(('Plano A','4h a R$ 60'),('Plano B','3h a R$ 55 + 1h extra'),('Plano C','2h a R$ 55 + 2h extras'),('Plano D','4h a R$ 65')),(2,),'Quanto você recebe pela proposta vencedora?','275','2 × 55 + 2 × 55 × 1,5 = 275.'),
 Jogo('bank_infl','banco','Proteja seu dinheiro','R$ 1.000 durante um mês. Inflação fictícia de 2%. Escolha a opção que supera a inflação e tem o maior saldo final.',(('Conta corrente','0%'),('Poupança fictícia','1%'),('CDB fictício','1,5%'),('Aplicação D','2,5%')),(3,),'Qual é o saldo nominal ao final do mês?','1025','1.000 × 1,025 = 1.025. A inflação é 2%, abaixo dos 2,5% nominais.'),
 Jogo('loja_manut','loja','Custo de manutenção','Compare bicicletas de qualidade equivalente, incluindo a manutenção prevista de um ano. Escolha o menor custo total.',(('Bicicleta A','R$ 320 + R$ 80'),('Bicicleta B','R$ 290 + R$ 150'),('Bicicleta C','R$ 350 + R$ 40'),('Bicicleta D','R$ 300 + R$ 110')),(2,),'Qual é o custo total no primeiro ano?','390','350 + 40 = 390. O preço de compra não é o único custo.'),
 Jogo('quiosque_eq','negocio','Ponto de equilíbrio','Custo fixo R$ 36, custo por lanche R$ 6 e preço R$ 12. Escolha a menor quantidade de vendas que cobre todos os custos.',(('Plano A','4 lanches'),('Plano B','5 lanches'),('Plano C','6 lanches'),('Plano D','8 lanches')),(2,),'Qual é a receita no ponto de equilíbrio?','72','36 ÷ (12 − 6) = 6 lanches; receita = 6 × 12 = 72.'),
)
POR_ID={j.id:j for j in JOGOS}
LOCAIS={'casa':'Casa','mercado':'Supermercado','empresa':'Empresa','banco':'Banco','loja':'Bicicletaria','negocio':'Quiosque'}
XP=30

def opcoes_corretas(jogo):
 return (jogo.escolha,)

def escolha_correta(jogo,indices):
 try: return frozenset(indices) in tuple(frozenset(x) for x in opcoes_corretas(jogo))
 except TypeError: return False

def selecionar(jogo,indices,idx):
 """Cartas únicas alternam; múltiplas nunca ultrapassam o limite."""
 s=set(indices); limite=len(jogo.escolha)
 if idx not in range(len(jogo.cartas)): return s,'Carta inválida.'
 if idx in s: s.remove(idx); return s,''
 if limite==1: return {idx},''
 if len(s)>=limite: return s,f'Escolha apenas {limite} cartas. Clique numa marcada para trocar.'
 s.add(idx); return s,''

DICAS_ESTRATEGIA={
 'casa_orc':'Separe aluguel e alimentação dos desejos; some só as necessidades.',
 'casa_res':'Use dinheiro próprio antes de recorrer a crédito.',
 'merc_cesta':'Confira os quilos e compare o menor preço total.',
 'merc_oferta':'Calcule o preço após cada desconto e compare.',
 'emp_turno':'Compare o valor dos turnos de 4 horas; escolha os dois mais bem pagos.',
 'emp_contas':'Escolha uma nota de papel e uma de toner; compare os custos.',
 'bank_inv':'Compare as taxas mensais líquidas; procure a maior.',
 'bank_juros':'Compare os totais após dois meses, não apenas as taxas.',
 'loja_bike':'Compare os totais e preserve pelo menos R$ 100 na carteira.',
 'loja_parc':'Elimine parcelas acima de R$ 100 e compare os totais restantes.',
 'quiosque_est':'Some o custo das dez unidades e o frete de cada lote.',
 'quiosque_luc':'Multiplique (preço − custo) pela quantidade de cada proposta.',
 'casa_contas':'Some todas as cobranças e compare os totais até R$ 130.',
 'merc_unit':'Divida cada preço pelo número de litros.',
 'emp_extra':'Calcule cada pagamento; multiplique a hora extra por 1,5.',
 'bank_infl':'Compare as taxas com 2% de inflação e entre si.',
 'loja_manut':'Some o custo de aquisição e a manutenção anual.',
 'quiosque_eq':'Divida o custo fixo pelo ganho por lanche e confira a quantidade.',
}
DICAS_CALCULO=(
 'Subtraia as despesas essenciais de R$ 700.', 'Subtraia da reserva apenas a parte não paga pela carteira.',
 'Some os preços das cartas escolhidas.', 'Multiplique o preço pelo fator após o desconto.',
 'Multiplique as horas pelos valores por hora e some os turnos.', 'Subtraia a soma das notas de R$ 300.',
 'Some o capital ao rendimento de um mês.', 'Calcule o capital mais os juros simples de dois meses.',
 'Subtraia o preço escolhido dos R$ 500.', 'Multiplique a parcela pela quantidade de meses.',
 'Multiplique dez pelo preço unitário e some o frete.', 'Multiplique o ganho unitário pela quantidade vendida.',
 'Subtraia as cobranças do orçamento de R$ 130.', 'Divida o preço escolhido pelos litros.',
 'Some horas normais e extras com seus respectivos valores.', 'Some a R$ 1.000 o rendimento nominal de um mês.',
 'Some o preço e a manutenção da bicicleta escolhida.', 'Multiplique a quantidade escolhida pelo preço de venda.',
)
DICA_CALCULO={j.id:d for j,d in zip(JOGOS,DICAS_CALCULO)}

def erro_estrategia(jogo,indices):
 s=set(indices); n=len(jogo.escolha)
 if len(s)!=n: return f'Selecione exatamente {n} '+('carta.' if n==1 else 'cartas.')
 if jogo.id=='emp_turno' and sum((4,4,4,2)[i] for i in s)!=8: return 'Os turnos não somam 8 horas. Escolha dois de 4 horas.'
 if jogo.id=='emp_contas' and len(s&{0,2})!=1: return 'Escolha uma nota de papel e uma nota de toner.'
 if jogo.id=='merc_cesta' and (2*int(0 in s)+int(1 in s)!=2 or len(s&{2,3})!=1): return 'Confira as quantidades: exatamente 2 kg de arroz e 1 kg de feijão.'
 return DICAS_ESTRATEGIA[jogo.id]

def numero_correto(jogo,texto):
 return correto(texto,jogo.resposta)

def validar(id,indices,texto):
 j=POR_ID.get(id)
 return bool(j and escolha_correta(j,indices) and numero_correto(j,texto))

# Painel de estratégia: exibe restrições e quantidades intermediárias, sem entregar
# o resultado solicitado na etapa de cálculo.
def indicador(jogo,indices):
 s=set(indices)
 if jogo.id=='merc_cesta':
  return f'Arroz: {2*int(0 in s)+int(1 in s)}/2 kg    •    Feijão: {int(2 in s)+int(3 in s)}/1 kg'
 if jogo.id=='emp_turno':
  return f'Horas escolhidas: {sum((4,4,4,2)[i] for i in s)}/8 h    •    Turnos: {len(s)}/2'
 if jogo.id=='emp_contas':
  return f'Papel: {3*(int(0 in s)+int(2 in s))}/3 caixas   •   Toners: {2*(int(1 in s)+int(3 in s))}/2'
 if jogo.id=='casa_orc': return f'Contas selecionadas: {len(s)}    •    Orçamento inicial: R$ 700'
 if jogo.id=='casa_res': return f'Fontes selecionadas: {len(s)}/2    •    Emergência: R$ 220'
 return f'Plano selecionado: {len(s)}/1    •    Compare as quatro propostas.'
