"""Orientação da campanha: estado atual, sem alterar o save."""
from economia import brl
from campanha import METAS

LOCAIS=('Empresa','Casa','Supermercado','Supermercado','Banco','Bicicletaria','Empresa / orçamento','Banco','Banco','Banco / Casa','Supermercado','Empresa','Quiosque','Quiosque','Toda a cidade')

def passos(eco,i):
 s=eco.estado; p=eco.progresso(i,s); sim=lambda v:'OK' if v else 'Pendente'
 if p['concluida']: return ['Meta concluída e salva.']
 r=[lambda:[f'Horas trabalhadas: {min(8,s["horas_total"])}/8 h.'],lambda:[f'Aluguel do período: {sim(s["aluguel"])}.'],lambda:[f'Compras em oferta: {min(1,s["ofertas"])}/1.'],lambda:[f'Compras de alimentos: {min(3,s["compras"])}/3.'],lambda:[f'Reserva: {brl(s["reserva"])} / R$ 500,00.'],lambda:[f'Bicicleta adquirida: {sim(s["bicicleta"])}.'],lambda:[f'Orçamento aberto: {sim(s["orçamento_visto"])}; salários: {brl(s["salarios"])} / R$ 1.000,00.'],lambda:[f'Simulação de crédito ou fatura paga: {sim(s["credito_visto"])}.'],lambda:[f'Comparação de juros no banco: {sim(s["emprestimo_visto"])}.'],lambda:[f'CDB atual: {brl(s["cdb"])}; rendimento recebido: {sim(s["rendeu_cdb"])}.', 'Rendimento no início do próximo mês virtual.'],lambda:[f'Dia {s["dia"]}/31; compra após inflação: {sim(s["compra_inflacao"])}.'],lambda:[f'Horas: {s["horas_total"]}/40; XP: {s["xp"]}/400; promoção: {sim(s["promocao"])}.'],lambda:[f'Quiosque aberto: {sim(s["negocio"])}; dias de venda: {s["vendas_dias"]}/1.'],lambda:[f'Dias de venda: {s["vendas_dias"]}/5; lucro bruto: {brl(s["lucro_bruto"])} / R$ 150,00.'],lambda:[f'Dia {s["dia"]}/60; patrimônio: {brl(eco.patrimonio(s))} / R$ 6.000,00.',f'Dívidas: {brl(eco.divida(s))} (meta R$ 0); reserva: {brl(s["reserva"])} / R$ 500,00.']][i]()
 return r
