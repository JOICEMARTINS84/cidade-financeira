"""Economia fictícia; valores monetários em centavos. Migração compatível V1/V2.
V3.1: imprevistos, rendimento da reserva, multa de aluguel, jornada em horas, margem no quiosque."""
import sqlite3
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from campanha import METAS, perguntas, correto
import csv, random
import expansao as ex
from minijogos import JOGOS, POR_ID, XP as XP_MINI, validar

def brl(c):
 return 'R$ '+f'{c/100:,.2f}'.replace(',','X').replace('.',',').replace('X','.')

HORAS_DIA=8
RENDIMENTO_MES=0.01   # 1% ao mês sobre a reserva (fictício)
MULTA_ALUGUEL=4500
IMPREVISTOS=[('Consulta médica',15000),('Conserto do celular',22000),('Conta de luz acima do normal',9000)]
PROFISSOES={'Atendente':(5500,18),'Auxiliar administrativo':(6500,24),'Entregador':(7500,30)}
EXTRAS={'profissao':"TEXT NOT NULL DEFAULT ''",'negocio':'INTEGER NOT NULL DEFAULT 0','estoque':'INTEGER NOT NULL DEFAULT 0','custo_unit':'INTEGER NOT NULL DEFAULT 0','preco':'INTEGER NOT NULL DEFAULT 1200','venda_dia':'INTEGER NOT NULL DEFAULT 0','receita':'INTEGER NOT NULL DEFAULT 0','lucro':'INTEGER NOT NULL DEFAULT 0'}
EXTRAS.update({k:'INTEGER NOT NULL DEFAULT 0' for k in ['horas_total','compras','ofertas','salarios','orçamento_visto','credito_visto','emprestimo_visto','cdb','rendeu_cdb','compra_inflacao','promocao','vendas_dias','lucro_bruto','cartao','emprestimo','contas','ajudante','evento','finalizado','tutorial','descanso_dia']})
EXTRAS.update({'nivel':"TEXT NOT NULL DEFAULT 'EF'",'aprendi':"TEXT NOT NULL DEFAULT ''",'produto':"TEXT NOT NULL DEFAULT 'Lanches'",'hora':'INTEGER NOT NULL DEFAULT 8'})
EXTRAS.update(ex.COLUNAS)
EXTRAS.update({'nome':"TEXT NOT NULL DEFAULT ''",'personagem':"TEXT NOT NULL DEFAULT 'homem'"})
def taxa(v,p): return int((Decimal(v)*Decimal(str(p))/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
class Economia:
 def __init__(self,path):
  self.db=sqlite3.connect(path); self.db.row_factory=sqlite3.Row
  self.db.executescript('''CREATE TABLE IF NOT EXISTS jogador(id INTEGER PRIMARY KEY CHECK(id=1), saldo INTEGER NOT NULL, reserva INTEGER NOT NULL, comida INTEGER NOT NULL, energia INTEGER NOT NULL, dia INTEGER NOT NULL, aluguel INTEGER NOT NULL, bicicleta INTEGER NOT NULL, parcelas INTEGER NOT NULL, xp INTEGER NOT NULL, turnos INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS historico(id INTEGER PRIMARY KEY AUTOINCREMENT, dia INTEGER, descricao TEXT, variacao INTEGER);''')
  with self.db:
   cols={x[1] for x in self.db.execute('PRAGMA table_info(jogador)')}
   for name,typ in EXTRAS.items():
    if name not in cols: self.db.execute(f'ALTER TABLE jogador ADD COLUMN {name} {typ}')
   self.db.executescript('CREATE TABLE IF NOT EXISTS metas(id INTEGER PRIMARY KEY, concluida INTEGER DEFAULT 0); CREATE TABLE IF NOT EXISTS respostas(meta INTEGER, questao INTEGER, acertos INTEGER DEFAULT 0, tentativas INTEGER DEFAULT 0, PRIMARY KEY(meta,questao)); CREATE TABLE IF NOT EXISTS movimentos(id INTEGER PRIMARY KEY, dia INTEGER, categoria TEXT, valor INTEGER); CREATE TABLE IF NOT EXISTS bonus(id TEXT PRIMARY KEY); CREATE TABLE IF NOT EXISTS minijogos(id TEXT PRIMARY KEY, dia INTEGER NOT NULL, xp INTEGER NOT NULL);')
   self._novo()
 def _novo(self):
  self.db.execute('INSERT OR IGNORE INTO jogador(id,saldo,reserva,comida,energia,dia,aluguel,bicicleta,parcelas,xp,turnos) VALUES(1,150000,0,1,100,1,0,0,0,0,0)')
 @property
 def estado(self): return dict(self.db.execute('SELECT * FROM jogador WHERE id=1').fetchone())
 def personalizar(self,nome,personagem):
  nome=' '.join(str(nome).split())
  if not nome or len(nome)>24 or personagem not in ('homem','mulher') or not any(c.isalpha() for c in nome) or not all(c.isalnum() or c in " -'" for c in nome): return False
  with self.db: self.db.execute('UPDATE jogador SET nome=?,personagem=? WHERE id=1',(nome,personagem))
  return True
 def historico(self): return list(self.db.execute('SELECT dia,descricao,variacao FROM historico ORDER BY id DESC LIMIT 8'))
 def custo_estoque(self,s): return 600+100*((s['dia']-1)%3)
 def custo_atual(self,s): return s['custo_unit'] if s['estoque'] else self.custo_estoque(s)
 def imprevisto(self,dia):
  return IMPREVISTOS[(dia//7)%len(IMPREVISTOS)] if dia%7==0 else None
 def demanda(self,s): return max(1,(9 if s['preco']==1000 else 7 if s['preco']==1200 else 4)+((s['dia']-1)%3)-1+(2 if s['dia']%7 in (0,6) else 0)-(2 if self.clima(s)=='Chuva' else 0)+(2 if s['ajudante'] else 0)+(3 if s.get('empresa_ampliada') else 0))
 def _opcoes_base(self,local):
  s=self.estado; p=s['profissao']; taxa,energia=PROFISSOES.get(p,(5000,20)); taxa+=taxa*s['promocao']//5
  if local=='casa': return [('dormir','Dormir até amanhã','Recupera energia; usa 1 alimento'+(' e paga parcela de R$ 110' if s['parcelas'] else '')),('aluguel','Pagar aluguel','R$ 450 por período de 30 dias')]
  if local=='mercado': return [('cesta1','Cesta econômica','R$ 120 | 1 alimento'),('cesta2','Cesta variada','R$ 180 | 2 alimentos'),('promo','Oferta de 20%','De R$ 180 por R$ 144 | 2 alimentos')]
  if local=='banco': return [('guardar200','Guardar R$ 200','Transferir para reserva'),('guardar500','Guardar R$ 500','Transferir para reserva'),('resgatar','Resgatar R$ 200','Transferir para carteira')]
  if local=='loja': return [('vista','Bicicleta à vista','R$ 320 com desconto de 20%'),('prazo','Bicicleta parcelada','4 × R$ 110 = R$ 440')]
  if local=='empresa':
   if not p: return [(f'cargo:{k}',k,f'{brl(v[0])}/h | energia -{v[1]} por turno de 4h') for k,v in PROFISSOES.items()]
   return [('turno4','Trabalhar 4 horas',f'{brl(4*taxa)} | energia -{energia} | restam {max(0,HORAS_DIA-s["turnos"])} h hoje'),('turno2','Trabalhar 2 horas',f'{brl(2*taxa)} | energia -{energia//2} | restam {max(0,HORAS_DIA-s["turnos"])} h hoje'),('trocar','Trocar de profissão','Escolher outro cargo; mantém o limite de horas do dia')]
  if local=='negocio':
   if not s['negocio']: return [('abrir','Abrir quiosque','Investimento inicial de R$ 350')]
   return [('comprar','Comprar lote de 10 produtos',f'{brl(10*self.custo_estoque(s))} | estoque deve estar vazio'),*[(f'preco{v}',f'Preço de venda: R$ {v}',f'Margem {brl(v*100-self.custo_atual(s))}/un | '+d) for v,d in ((10,'maior procura'),(12,'procura intermediária'),(15,'menor procura'))],('vender','Abrir para vendas',f"Até {self.demanda(s)} unidades hoje | estoque: {s['estoque']}")]
  return []
 def _agir_base(self,local,acao):
  s=self.estado; opts={a:n for a,n,_ in self.opcoes(local)}
  if acao not in opts: return False,'Opção indisponível.'
  nome=opts[acao]; antes=s['saldo']; msg=''; xp=20
  def fail(msg): return False,msg
  if acao in ('cesta1','cesta2','promo'):
   custo,quant=self.precos(s)[acao]; s['saldo']-=custo; s['comida']+=quant; msg=f'{quant} alimento(s) por {brl(custo)}. '+(f' Oferta: 20% de desconto sobre {brl(self.precos(s)["cesta2"][0])}.' if acao=='promo' else f'Preço por unidade: {brl(custo//quant)}.')
  elif acao=='dormir':
   if s['comida']<1: return fail('Compre comida antes de dormir.')
   s['comida']-=1; s['energia']=100; s['dia']+=1; s['turnos']=0; pago_antes=s['aluguel']
   if (s['dia']-1)%30==0: s['aluguel']=0
   msg='Novo dia, energia recuperada.'
   if s['parcelas']:
    s['parcelas']-=1; pago=min(s['saldo'],11000); s['saldo']-=pago; s['contas']+=11000-pago; msg+=f' Parcela: {brl(pago)} paga; restante em contas abertas.' if pago<11000 else ' Parcela de R$ 110 paga.'
   if (s['dia']-1)%30==0:
    if not pago_antes and s['dia']>30:
     m=min(MULTA_ALUGUEL,max(0,s['saldo'])); s['saldo']-=m; s['contas']+=MULTA_ALUGUEL-m; msg+=f' Aluguel atrasado: multa de {brl(m)}.'
    if s['reserva']>0:
     r=int(s['reserva']*RENDIMENTO_MES); s['reserva']+=r; msg+=f' Rendimento da reserva (1% ao mês): +{brl(r)}.'
   ev=self.imprevisto(s['dia'])
   if ev:
    nome_ev,valor=ev; da_carteira=min(valor,max(0,s['saldo'])); s['saldo']-=da_carteira; falta=valor-da_carteira; da_reserva=min(falta,s['reserva']); s['reserva']-=da_reserva; falta-=da_reserva
    msg+=f' Imprevisto: {nome_ev} ({brl(valor)}).'
    if da_reserva: msg+=f' Reserva usada: {brl(da_reserva)}.'; s['xp']+=30
    if falta: s['contas']+=falta; msg+=f' Faltaram {brl(falta)}: sem reserva, a conta ficou em aberto!'
  elif acao=='aluguel':
   if s['aluguel']: return fail('Aluguel deste período já pago.')
   s['saldo']-=45000; s['aluguel']=1; msg='Aluguel de R$ 450 pago.'
  elif acao in ('guardar200','guardar500','resgatar'):
   valor={'guardar200':20000,'guardar500':50000,'resgatar':-20000}[acao]; s['saldo']-=valor; s['reserva']+=valor; xp=0; msg='Transferência efetuada. Seu patrimônio não mudou.'
  elif acao in ('vista','prazo'):
   if s['bicicleta']: return fail('Você já tem uma bicicleta.')
   s['bicicleta']=1; s['parcelas']=3 if acao=='prazo' else 0; s['saldo']-=11000 if acao=='prazo' else 32000; msg='4 × R$ 110 = R$ 440; R$ 120 a mais que à vista.' if acao=='prazo' else 'R$ 400 − 20% = R$ 320.'
  elif acao.startswith('cargo:'):
   s['profissao']=acao.split(':',1)[1]; xp=0; msg='Contratação realizada! Escolha um turno.'
  elif acao=='trocar': s['profissao']=''; xp=0; msg='Escolha a nova profissão.'
  elif acao in ('turno4','turno2'):
   taxa,energia=PROFISSOES[s['profissao']]; taxa+=taxa*s['promocao']//5; horas=4 if acao=='turno4' else 2
   if s['turnos']+horas>HORAS_DIA: return fail(f'Limite de {HORAS_DIA} horas de trabalho por dia. Restam {HORAS_DIA-s["turnos"]} h.')
   s['energia']-=energia if horas==4 else energia//2; s['saldo']+=horas*taxa; s['turnos']+=horas; msg=f'{horas} h × {brl(taxa)} = {brl(horas*taxa)} de salário.'
  elif acao=='abrir': s['saldo']-=35000; s['negocio']=1; s['lucro']-=35000; msg='Quiosque aberto! Investimento de R$ 350. Compre estoque para começar.'
  elif acao=='comprar':
   if s['estoque']: return fail('Venda o lote atual antes de comprar outro.')
   s['custo_unit']=self.custo_estoque(s); s['estoque']=10; s['saldo']-=10*s['custo_unit']; msg=f"10 × {brl(s['custo_unit'])} = {brl(10*s['custo_unit'])}. Estoque adquirido."
  elif acao.startswith('preco'): s['preco']=int(acao[5:])*100; xp=0; msg=f"Preço definido: {brl(s['preco'])}. Procura estimada hoje: {self.demanda(s)} unidades."
  elif acao=='vender':
   if s['venda_dia']==s['dia']: return fail('Seu quiosque já vendeu hoje. Volte amanhã.')
   if not s['estoque']: return fail('Não há produtos no estoque.')
   q=min(s['estoque'],self.demanda(s)); receita=q*s['preco']; custo=q*s['custo_unit']; lucro=receita-custo; s['lucro_bruto']+=lucro; s['vendas_dias']+=1; s['saldo']+=receita; s['receita']+=receita; s['lucro']+=lucro; s['estoque']-=q; s['venda_dia']=s['dia']; s['energia']-=10; msg=f'{q} vendas: receita {brl(receita)} − custo {brl(custo)} = lucro {brl(lucro)}.'
  if s['saldo']<0: return fail('Saldo insuficiente. Nenhuma alteração foi feita.')
  if s['reserva']<0: return fail('Reserva insuficiente.')
  if s['energia']<0: return fail('Energia insuficiente. Descanse.')
  s['xp']+=xp; cols=[k for k in s if k!='id']
  self._gravar(s); self.db.execute('INSERT INTO historico(dia,descricao,variacao) VALUES(?,?,?)',(s['dia'],nome,s['saldo']-antes))
  return True,msg
 def reset(self):
  with self.db: self.db.execute('DELETE FROM jogador'); self.db.execute('DELETE FROM historico'); [self.db.execute('DELETE FROM '+x) for x in ('metas','respostas','movimentos','bonus','minijogos')]; self._novo()
 def _gravar(self,s):
  cols=[k for k in s if k!='id']; self.db.execute('UPDATE jogador SET '+','.join(k+'=?' for k in cols)+' WHERE id=1',[s[k] for k in cols])
 def precos(self,s):
  fator=Decimal('1.02')**((s['dia']-1)//30); a=int((12000*fator).quantize(Decimal('1'),rounding=ROUND_HALF_UP)); b=int((18000*fator).quantize(Decimal('1'),rounding=ROUND_HALF_UP)); return {'cesta1':(a,1),'cesta2':(b,2),'promo':(b-taxa(b,20),2)}
 def clima(self,s): return 'Chuva' if s['dia']%5==0 else 'Sol'
 def divida(self,s=None):
  s=s or self.estado; return s['cartao']+s['emprestimo']+s['contas']+s['parcelas']*11000+ex.debito(s)
 def patrimonio(self,s=None):
  s=s or self.estado; return s['saldo']+s['reserva']+s['cdb']+s['estoque']*s['custo_unit']-self.divida(s)
 def patrimonio_total(self,s=None):
  s=s or self.estado
  return self.patrimonio(s)+ex.ativos(s)
 def agir_expansao(self,area,id,texto):
  s=self.estado; ok,msg,n,mov=ex.aplicar(area,id,texto,s)
  if not ok: return False,msg,0
  with self.db:
   cur=self.db.execute('INSERT OR IGNORE INTO bonus VALUES(?)',('expansao:'+id,)); xp=15 if cur.rowcount else 0
   n['xp']+=xp; n['aprendi']=msg; self._gravar(n)
   self.db.execute('INSERT INTO historico(dia,descricao,variacao) VALUES(?,?,?)',(n['dia'],'Distrito: '+id,mov))
   if mov: self._mov(n['dia'],'Distrito: '+area,mov)
   if ex.concluida(area,n):
    c=self.db.execute('INSERT OR IGNORE INTO bonus VALUES(?)',('distrito_meta:'+area,))
    if c.rowcount:
     xp+=50; n['xp']+=50; msg+=' Objetivo extra concluído!'; n['aprendi']=msg; self._gravar(n)
   self._atualizar()
  return True,msg,xp
 def metas_expansao(self):
  return {r[0].split(':',1)[1] for r in self.db.execute("SELECT id FROM bonus WHERE id LIKE 'distrito_meta:%'")}
 def conquistas_expansao(self):
  return {r[0].split(':',1)[1] for r in self.db.execute("SELECT id FROM bonus WHERE id LIKE 'expansao:%'")}
 def opcoes(self,local):
  s=self.estado; o=self._opcoes_base(local)
  if local=='mercado':
   o=[(k,n,f'{brl(self.precos(s)[k][0])} | {self.precos(s)[k][1]} alimento(s)') for k,n,_ in o]; o+=[('cartao_compra','Cesta no cartão',f'{brl(self.precos(s)["cesta1"][0])} | limite R$ 600; 5% a.m.')] 
  if local=='banco':
   o += [('sim_credito','Simular cartão','R$ 200 a 5% ao mês = R$ 210 após 1 mês'),('sim_emprestimo','Comparar juros','R$ 500 por 2 meses: simples R$ 540; composto R$ 540,80'),('emprestar','Contratar empréstimo','R$ 500 | 4% ao mês sobre saldo'),('pagar_emp','Amortizar empréstimo',brl(min(20000,s['emprestimo']))),('pagar_cartao','Pagar fatura',brl(s['cartao'])),('cdb200','Aplicar no CDB','R$ 200 | 1,5% ao mês fictício'),('resg_cdb','Resgatar CDB',brl(s['cdb'])),('pagar_contas','Quitar contas abertas',brl(s['contas']))]
  if local=='empresa' and s['profissao']: o += [('promover','Solicitar promoção','40 horas e 400 XP | +20% no salário')]
  if local=='negocio' and s['negocio']:
   o += [('lote_bebida','Bebidas • fornecedor Norte','10 unidades a R$ 5,50'),('lote_artes','Artesanato • fornecedor Sul','10 unidades a R$ 8,00'),('ajudante','Contratar ajudante','R$ 24 por dia de venda | +2 demanda'),('dispensar','Dispensar ajudante','Encerra custo por venda')]
  if local=='casa': o += [('sofa','Descansar no sofá','+15 energia, uma vez por dia')]
  if local=='casa' and s['evento']: o += [('evento_sim','Aceitar proposta','Ajudar amigo: R$ 80 | retorno não garantido'),('evento_nao','Recusar proposta','Preserva sua reserva')]
  return o
 def _mov(self,d,c,v):
  if v: self.db.execute('INSERT INTO movimentos(dia,categoria,valor) VALUES(?,?,?)',(d,c,v))
 def agir(self,local,acao):
  a=self.estado; s=a.copy(); opts={k:n for k,n,_ in self.opcoes(local)}
  if acao not in opts: return False,'Opção indisponível.'
  cat=None; msg=''; basekeys={k for k,_,_ in self._opcoes_base(local)}
  with self.db:
   if acao in basekeys:
    ok,msg=self._agir_base(local,acao)
    if not ok: return ok,msg
    s=self.estado
    if acao in ('cesta1','cesta2','promo'):
     s['compras']+=1; s['ofertas']+=int(acao=='promo'); s['compra_inflacao']|=int(s['dia']>=31); cat='Alimentação'
    elif acao.startswith('turno'):
     s['horas_total']+=int(acao[-1]); s['salarios']+=s['saldo']-a['saldo']; cat='Salários'
    elif acao=='aluguel': cat='Moradia'
    elif acao in ('vista','prazo'): cat='Transporte'
    elif acao=='abrir': cat='Negócio: instalação'
    elif acao=='comprar': s['produto']='Lanches'; cat='Negócio: estoque'
    elif acao=='vender':
     cat='Negócio: vendas'; self._mov(s['dia'],cat,s['saldo']-a['saldo']); cat=None
     if s['ajudante']:
      pago=min(2400,s['saldo']); s['saldo']-=pago; s['contas']+=2400-pago; s['lucro']-=2400; self._mov(s['dia'],'Negócio: ajudante',-2400); msg+=' Ajudante: R$ 24.'
    elif acao=='dormir':
     if a['parcelas']: self._mov(s['dia'],'Transporte',-11000)
     ev=self.imprevisto(s['dia'])
     if ev: self._mov(s['dia'],'Emergências',-ev[1])
     if (s['dia']-1)%30==0:
      r=taxa(s['cdb'],1.5); s['cdb']+=r; s['rendeu_cdb']|=int(r>0); self._mov(s['dia'],'Rendimento CDB',r)
      self._mov(s['dia'],'Rendimento reserva',s['reserva']-a['reserva'] if not ev else int(a['reserva']*RENDIMENTO_MES))
      for k,percent in [('cartao',5),('emprestimo',4)]:
       j=taxa(s[k],percent); s[k]+=j; self._mov(s['dia'],'Juros da dívida',-j)
      if not a['aluguel']:
       s['contas']+=45000; self._mov(s['dia'],'Moradia em aberto',-45000)
       self._mov(s['dia'],'Multa',-MULTA_ALUGUEL)
      msg+=f' CDB +{brl(r)}; preços +2% no mês.'
      for nome,valor in ex.virada(s):
       self._mov(s['dia'],nome,-valor); msg+=f' {nome}: {brl(valor)} (falta em contas).'
     if not s['evento'] and random.Random(s['dia']*37).random()<.16: s['evento']=1; msg+=' Um amigo trouxe uma proposta: veja em casa.'
   else:
    v=0
    if acao=='sim_credito': s['credito_visto']=1; msg='R$ 200 × 1,05 = R$ 210 após um mês.'
    elif acao=='sim_emprestimo': s['emprestimo_visto']=1; msg='Simples: R$ 540; composto: R$ 540,80. Diferença de R$ 0,80.'
    elif acao=='cartao_compra':
     v=self.precos(s)['cesta1'][0]
     if s['cartao']+v>60000: return False,'Limite do cartão atingido.'
     s['cartao']+=v; s['comida']+=1; s['compras']+=1; s['compra_inflacao']|=int(s['dia']>=31); self._mov(s['dia'],'Alimentação (crédito)',-v); msg='Compra no cartão: dívida aumenta; carteira permanece.'
    elif acao=='emprestar':
     if s['emprestimo']: return False,'Quite o empréstimo atual primeiro.'
     s['emprestimo']=50000; s['saldo']+=50000; msg='R$ 500 recebidos; dívida de R$ 500.'
    elif acao in ('pagar_emp','pagar_cartao','pagar_contas'):
     k={'pagar_emp':'emprestimo','pagar_cartao':'cartao','pagar_contas':'contas'}[acao]; v=min(20000,s[k]) if k=='emprestimo' else s[k]
     if not v or s['saldo']<v: return False,'Sem dívida ou saldo insuficiente.'
     s['saldo']-=v; s[k]-=v; s['credito_visto']|=int(k=='cartao'); msg=f'Dívida reduzida em {brl(v)}.'
    elif acao=='cdb200':
     if s['saldo']<20000: return False,'Saldo insuficiente.'
     s['saldo']-=20000; s['cdb']+=20000; msg='Aplicação de R$ 200 no CDB fictício.'
    elif acao=='resg_cdb':
     if not s['cdb']: return False,'Sem aplicação.'
     s['saldo']+=s['cdb']; s['cdb']=0; msg='CDB resgatado.'
    elif acao=='promover':
     if s['promocao'] or s['horas_total']<40 or s['xp']<400: return False,'Requer 40 horas, 400 XP e nenhuma promoção anterior.'
     s['promocao']=1; msg='Promoção: salário por hora +20%.'
    elif acao in ('lote_bebida','lote_artes'):
     v=550 if acao=='lote_bebida' else 800
     if s['estoque'] or s['saldo']<10*v: return False,'Estoque deve estar vazio e saldo suficiente.'
     s['estoque']=10; s['custo_unit']=v; s['saldo']-=10*v; s['produto']='Bebidas' if v==550 else 'Artesanato'; cat='Negócio: estoque'; msg=f'10 × {brl(v)} = {brl(10*v)}.'
    elif acao in ('ajudante','dispensar'):
     s['ajudante']=int(acao=='ajudante'); msg='Ajudante contratado.' if s['ajudante'] else 'Ajudante dispensado.'
    elif acao=='sofa':
     if s['descanso_dia']==s['dia'] or s['energia']==100: return False,'Já descansou hoje ou está com energia máxima.'
     s['descanso_dia']=s['dia']; s['energia']=min(100,s['energia']+15); msg='Descansar ajuda a manter a produtividade.'
    elif acao.startswith('evento_'):
     if acao=='evento_sim':
      if s['saldo']<8000: return False,'Saldo insuficiente.'
      s['saldo']-=8000; cat='Ajuda ao amigo'; msg='Você ajudou com R$ 80; não conte com retorno.'
     else: msg='Você preservou o orçamento.'
     s['evento']=0
    else: return False,'Opção indisponível.'
    self.db.execute('INSERT INTO historico(dia,descricao,variacao) VALUES(?,?,?)',(s['dia'],opts[acao],s['saldo']-a['saldo']))
   if cat: self._mov(s['dia'],cat,s['saldo']-a['saldo'])
   s['hora']=8 if acao=='dormir' else min(23,s['hora']+(int(acao[-1]) if acao in ('turno2','turno4') else 1 if acao not in ('sim_credito','sim_emprestimo') else 0)); s['aprendi']=msg; self._gravar(s); self._atualizar()
  return True,msg
 def requisitos(self,s=None):
  s=s or self.estado
  return [s['horas_total']>=8,bool(s['aluguel']),s['ofertas']>0,s['compras']>=3,s['reserva']>=50000,bool(s['bicicleta']),bool(s['orçamento_visto']) and s['salarios']>=100000,bool(s['credito_visto']),bool(s['emprestimo_visto']),bool(s['rendeu_cdb']),bool(s['compra_inflacao']),bool(s['promocao']),bool(s['negocio']) and s['vendas_dias']>=1,s['vendas_dias']>=5 and s['lucro_bruto']>=15000,s['dia']>=60 and self.patrimonio(s)>=600000 and self.divida(s)==0 and s['reserva']>=50000]
 def progresso(self,i,s=None):
  s=s or self.estado; feitas=self.concluidas(); acao=self.requisitos(s)[i]; respondidas=len(self.respondidas(i)); total=len(perguntas(i,s['nivel']))
  return {'acao':acao,'acertos':respondidas,'total':total,'concluida':i in feitas,'horas':s['horas_total'] if i==0 else None}
 def status_meta(self,i,s=None):
  p=self.progresso(i,s)
  if p['concluida']: return 'Concluída'
  acao=f"Trabalho {min(8,p['horas'])}/8 h" if i==0 else ('Ação OK' if p['acao'] else 'Ação pendente')
  return f"{acao} | Cálculos {p['acertos']}/{p['total']}"
 def concluidas(self): return {r[0] for r in self.db.execute('SELECT id FROM metas WHERE concluida=1')}
 def respondidas(self,i): return {r[0] for r in self.db.execute('SELECT questao FROM respostas WHERE meta=? AND acertos>0',(i,))}
 def _atualizar(self):
  s=self.estado; feitas=self.concluidas()
  for i,ok in enumerate(self.requisitos(s)):
   if i not in feitas and ok and len(self.respondidas(i))==len(perguntas(i,s['nivel'])):
    self.db.execute('INSERT OR REPLACE INTO metas VALUES(?,1)',(i,)); s['xp']+=100; s['aprendi']=METAS[i][4]
  if len(self.concluidas())==15 and self.requisitos(s)[14]: s['finalizado']=1
  self._gravar(s)
 def resposta(self,i,j,texto):
  s=self.estado; q=perguntas(i,s['nivel'])[j]; ok=correto(texto,q[1]); ja=j in self.respondidas(i)
  with self.db:
   self.db.execute('INSERT INTO respostas VALUES(?,?,?,1) ON CONFLICT(meta,questao) DO UPDATE SET acertos=max(acertos,excluded.acertos),tentativas=tentativas+1',(i,j,int(ok)))
   if ok and not ja: s['xp']+=15; s['aprendi']=q[2]; self._gravar(s)
   self._atualizar()
  return ok,q[2] if ok else 'Não foi desta vez. Revise o cálculo e tente novamente.'
 def nivel(self,n):
  if n not in ('EF','EM') or self.db.execute('SELECT 1 FROM respostas LIMIT 1').fetchone(): return False
  with self.db: self.db.execute('UPDATE jogador SET nivel=?',(n,))
  return True
 def orcamento(self):
  s=self.estado; inicio=(s['dia']-1)//30*30+1
  with self.db: self.db.execute('UPDATE jogador SET "orçamento_visto"=1'); self._atualizar()
  return list(self.db.execute('SELECT categoria,SUM(CASE WHEN valor>0 THEN valor ELSE 0 END),SUM(CASE WHEN valor<0 THEN -valor ELSE 0 END) FROM movimentos WHERE dia>=? AND dia<? GROUP BY categoria ORDER BY categoria',(inicio,inicio+30)))
 def exportar(self,pasta):
  pasta=Path(pasta); pasta.mkdir(parents=True,exist_ok=True)
  for nome,sql,header in [('extrato','SELECT dia,descricao,variacao FROM historico ORDER BY id',['Dia','Descrição','Variação carteira (centavos)']),('orcamento','SELECT dia,categoria,valor FROM movimentos ORDER BY id',['Dia','Categoria','Valor (centavos)'])]:
   with open(pasta/(nome+'.csv'),'w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f,delimiter=';'); w.writerow(header); w.writerows(self.db.execute(sql))
  with open(pasta/'relatorio.csv','w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f,delimiter=';'); s=self.estado; w.writerow(['Nome',s['nome'],'Personagem',s['personagem'],'Nível',s['nivel'],'Dia',s['dia'],'XP',s['xp'],'Patrimônio (centavos)',self.patrimonio(s)]); w.writerow(['Meta','BNCC','Concluída','Acertos','Tentativas','Aprendizagem'])
   for i,m in enumerate(METAS): w.writerow([m[0],m[1 if s['nivel']=='EF' else 2],int(i in self.concluidas()),len(self.respondidas(i)),self.db.execute('SELECT coalesce(sum(tentativas),0) FROM respostas WHERE meta=?',(i,)).fetchone()[0],m[4]])
  with open(pasta/'minijogos.csv','w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f,delimiter=';'); w.writerow(['Minijogo','Local','Concluído','Dia','XP'])
   feitos={r['id']:r for r in self.db.execute('SELECT * FROM minijogos')}
   for j in JOGOS:
    r=feitos.get(j.id); w.writerow([j.titulo,j.local,int(r is not None),r['dia'] if r else '',r['xp'] if r else 0])
  with open(pasta/'patrimonio.csv','w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f,delimiter=';'); s=self.estado; w.writerow(['Indicador','Valor']); w.writerows([('Patrimônio financeiro (centavos)',self.patrimonio(s)),('Patrimônio ampliado (centavos)',self.patrimonio_total(s)),('Financiamento restante (centavos)',ex.debito(s)),('Cotas',s['acoes']),('Preço da cota (centavos)',ex.preco(s['dia']))]); w.writerow(['Ações concluídas']); w.writerows((k,) for k in sorted(self.conquistas_expansao())); w.writerow(['Objetivos extras concluídos']); w.writerows((k,) for k in sorted(self.metas_expansao()))
  return pasta
 def minijogos_feitos(self):
  return {r[0] for r in self.db.execute('SELECT id FROM minijogos')}
 def concluir_minijogo(self,id,indices,texto):
  if not validar(id,indices,texto): return False,0
  with self.db:
   cur=self.db.execute('INSERT OR IGNORE INTO minijogos VALUES(?,?,?)',(id,self.estado['dia'],XP_MINI))
   if not cur.rowcount: return True,0
   self.db.execute('UPDATE jogador SET xp=xp+?, aprendi=?',(XP_MINI,POR_ID[id].explicacao)); self._atualizar()
  return True,XP_MINI
 def bonus(self,key,ok):
  if not ok: return False
  with self.db:
   cur=self.db.execute('INSERT OR IGNORE INTO bonus VALUES(?)',(key,))
   if cur.rowcount: self.db.execute('UPDATE jogador SET xp=xp+10'); return True
  return False
