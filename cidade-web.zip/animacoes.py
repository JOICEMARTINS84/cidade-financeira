"""Minicenas animadas das atividades (desenhadas por código, sem imagens novas).

Cada cena recebe `g` (funções de desenho fornecidas pelo main.py), `u` (progresso 0..1)
e `arg` (detalhes da ação). A área de desenho é SX,SY,SW,SH.
"""
import math

SX, SY, SW, SH = 205, 160, 690, 280
DURACAO = 3.2


def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def lerp(a, b, t): return a + (b - a) * t
def ease(t): t = clamp(t); return t * t * (3 - 2 * t)


def mix(c1, c2, t):
    t = clamp(t)
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return '#%02x%02x%02x' % tuple(int(lerp(x, y, t)) for x, y in zip(a, b))


def fundo(g, cor): g.rect((SX, SY, SW, SH), cor, 8)


def trabalhar(g, u, arg):
    horas = arg.get('horas', 4)
    fundo(g, '#26404a')
    g.rect((SX, SY + 215, SW, 65), '#8a6f55')
    mx, my, mw, mh = 400, 180, 300, 185
    g.rect((mx, my, mw, mh), '#1b2a31', 10)
    tela = (mx + 12, my + 12, mw - 24, mh - 24)
    prog = clamp((u - 0.3) / 0.62)
    if u > 0.18:
        g.rect(tela, mix('#0e1a1f', '#9fd0da', (u - 0.18) / 0.12), 4)
        g.rect((tela[0], tela[1], tela[2], 18), '#3d6e7c', 4)
        g.txt('Relatório do dia', tela[0] + 8, tela[1] + 2, 12, '#f4efd9', True)
        for i in range(min(int(prog * 10), 10)):
            w = 70 + (i * 37) % 90
            g.rect((tela[0] + 14, tela[1] + 30 + i * 13, w, 7), '#3d6e7c', 2)
            g.rect((tela[0] + 22 + w, tela[1] + 30 + i * 13, 34, 7), '#e0b45a', 2)
        g.rect((tela[0] + 14, tela[1] + tela[3] - 22, tela[2] - 28, 9), '#5d8c96', 4)
        g.rect((tela[0] + 14, tela[1] + tela[3] - 22, int((tela[2] - 28) * prog), 9), '#a7ce90', 4)
    else:
        g.rect(tela, '#0e1a1f', 4)
    g.circ('#a7ce90' if u > 0.05 else '#c0584e', (mx + mw - 22, my + mh - 7), 3)
    g.rect((mx + mw // 2 - 14, my + mh, 28, 22), '#33474f')
    g.rect((mx + mw // 2 - 45, my + mh + 20, 90, 8), '#33474f', 3)
    g.rect((mx + 30, SY + 238, 240, 18), '#d9d2bd', 4)
    if u > 0.3:
        for j in range(6):
            if (int(u * 18) + j) % 3 == 0:
                g.rect((mx + 42 + j * 38, SY + 241, 28, 6), '#8f9a98', 2)
    h = 8 + horas * prog
    g.rect((SX + SW - 130, SY + 14, 112, 38), '#192f39', 8)
    g.txt('%02d:%02d' % (int(h), int((h - int(h)) * 60)), SX + SW - 74, SY + 33, 24, '#f5dfaa', True, True)
    g.blit(g.sprite('right', 3), (270, SY + 70))


def dormir(g, u, arg):
    dia = ease((u - 0.62) / 0.3)
    bg = mix('#0f1d33', '#f0c98a', dia)
    fundo(g, bg)
    if dia < 0.9:
        for i in range(14):
            br = (math.sin(u * 9 + i) + 1) / 2
            g.circ(mix(bg, '#f4efd9', br * (1 - dia)), (SX + 30 + (i * 97) % 640, SY + 16 + (i * 53) % 110), 2)
    g.circ(mix('#f4efd9', bg, dia), (SX + 110, SY + 70 + dia * 140), 24)
    g.circ('#ffd36b', (SX + SW - 110, SY + SH + 40 - ease((u - 0.55) / 0.4) * 170), 32)
    g.rect((SX, SY + 215, SW, 65), '#6b5444')
    resp = math.sin(u * 14) * 2 * (1 - dia)
    g.rect((400, SY + 170, 300, 55), '#7c5a45', 6)
    g.rect((410, SY + 150, 280, 40), '#f1e5c7', 6)
    g.ellipse('#fffaf0', (418, SY + 140, 70, 34))
    g.rect((480, SY + 140 + resp - (12 if dia > 0.5 else 0), 210, 52), '#5e9aa5', 8)
    if dia < 0.6:
        for i in range(3):
            t = (u * 2 + i * 0.33) % 1
            g.txt('Z', 440 + i * 20 + t * 30, SY + 120 - t * 90, 18 + i * 6, mix(bg, '#f4efd9', 1 - t), True)
    else:
        g.txt('Bom dia!', SX + SW // 2, SY + 40, 30, '#7a4a2a', True, True)


def pagar(g, u, arg):
    fundo(g, '#2b4650')
    g.rect((SX + 50, SY + 110, 150, 120), '#b86c5b', 4)
    g.polygon('#8b4b3d', [(SX + 35, SY + 112), (SX + 125, SY + 45), (SX + 215, SY + 112)])
    g.rect((SX + 105, SY + 165, 40, 65), '#5a3a30', 3)
    g.rect((SX + SW - 190, SY + 150, 130, 80), '#8a5a44', 8)
    g.txt('Carteira', SX + SW - 125, SY + 235, 14, '#c0d0cf', True, True)
    g.rect((SX + 290, SY + 30, 170, 190), '#f1e8cc', 4)
    for i in range(6):
        g.rect((SX + 306, SY + 50 + i * 16, 90 + (i * 23) % 50, 6), '#b9ad8a', 2)
    for i in range(3):
        t = clamp((u - 0.1 - i * 0.15) / 0.4)
        if 0 < t < 1:
            e = ease(t)
            g.circ('#e0b45a', (lerp(SX + SW - 125, SX + 375, e), SY + 170 - math.sin(e * math.pi) * 70), 11)
    if u > 0.7:
        k = ease((u - 0.7) / 0.15)
        g.rect((SX + 310, SY + 150, 120, 44), '#5b9a5f' if k > 0.5 else '#f1e8cc', 6)
        g.txt('PAGO', SX + 370, SY + 172, int(18 + 8 * k), '#f4efd9', True, True)


def comprar(g, u, arg):
    n = arg.get('itens', 3)
    fundo(g, '#2f4a50')
    g.rect((SX + 20, SY + 150, 430, 22), '#3b4b50', 4)
    for i in range(0, 430, 30):
        g.rect((SX + 20 + (i + u * 240) % 410, SY + 153, 4, 16), '#56686d')
    cores = ['#d9785f', '#e0b45a', '#8fb98a', '#7fa8c4', '#c58fb0', '#d9ba75']
    cesta = (SX + 480, SY + 130, 150, 90)
    g.rect((cesta[0], cesta[1] + 12, cesta[2], cesta[3] - 12), '#a8793f', 8)
    chegou = 0
    for i in range(n):
        t = clamp((u - 0.05 - i * (0.6 / n)) / 0.3)
        if t <= 0:
            continue
        if t < 1:
            g.rect((SX + 30 + t * 400, SY + 122, 26, 28), cores[i % 6], 4)
        else:
            chegou += 1
            g.circ(cores[i % 6], (cesta[0] + 20 + (i % 5) * 28, cesta[1] + 12 - (i // 5) * 14), 11)
    g.rect((cesta[0] + 10, cesta[1] - 12, cesta[2] - 20, 10), '#a8793f', 4)
    g.rect((SX + 480, SY + 30, 150, 60), '#192f39', 8)
    g.txt('%d item(ns)' % chegou, SX + 555, SY + 60, 20, '#a7ce90', True, True)
    if arg.get('promo'):
        g.rect((SX + 40, SY + 40, 120, 40), '#e0b45a', 8)
        g.txt('-20%', SX + 100, SY + 60, 24, '#5a3a30', True, True)


def banco(g, u, arg):
    saindo = arg.get('saindo', False)
    n = arg.get('moedas', 3)
    fundo(g, '#2b4650')
    g.ellipse('#d99a9a', (SX + 230, SY + 110, 230, 130))
    g.polygon('#c98585', [(SX + 400, SY + 118), (SX + 425, SY + 85), (SX + 440, SY + 125)])
    g.ellipse('#e6aeae', (SX + 425, SY + 150, 60, 44))
    g.circ('#5a3a30', (SX + 400, SY + 150), 5)
    for dx in (260, 400):
        g.rect((SX + dx, SY + 218, 28, 32), '#c98585', 6)
    g.rect((SX + 320, SY + 112, 50, 7), '#7a4a4a', 3)
    carteira = (SX + 590, SY + 60)
    g.rect((carteira[0] - 45, carteira[1] - 25, 90, 55), '#8a5a44', 8)
    for i in range(n):
        t = clamp((u - 0.1 - i * 0.14) / 0.35)
        if 0 < t < 1:
            e = ease(t if saindo else 1 - t)
            pos = (lerp(SX + 345, carteira[0], e), lerp(SY + 112, carteira[1], e) - math.sin(e * math.pi) * 60)
            g.circ('#e0b45a', pos, 11)
    g.txt('Reserva' if not saindo else 'Resgate', SX + 345, SY + 255, 15, '#c0d0cf', True, True)


def bicicleta(g, u, arg):
    fundo(g, '#d9d1b0')
    g.rect((SX, SY + 232, SW, 48), '#9c8f73')
    x = lerp(SX + 90, SX + SW // 2, ease(u / 0.7))
    y = SY + 205
    ang = u * 16
    for cx in (x - 70, x + 70):
        g.circ('#33424a', (cx, y), 44)
        g.circ('#d9d1b0', (cx, y), 38)
        for k in range(4):
            a = ang + k * math.pi / 4
            g.line('#6c7b80', (cx - 38 * math.cos(a), y - 38 * math.sin(a)), (cx + 38 * math.cos(a), y + 38 * math.sin(a)), 2)
    cor = '#b8574a'
    pts = [((x - 70, y), (x - 15, y - 70)), ((x - 15, y - 70), (x + 55, y - 70)), ((x + 55, y - 70), (x + 70, y)),
           ((x - 70, y), (x - 5, y)), ((x - 5, y), (x - 15, y - 70)), ((x - 5, y), (x + 55, y - 70))]
    for a, b in pts:
        g.line(cor, a, b, 6)
    g.line('#33424a', (x - 28, y - 78), (x + 2, y - 78), 8)
    g.line('#33424a', (x + 55, y - 70), (x + 62, y - 95), 5)
    g.line('#33424a', (x + 52, y - 98), (x + 76, y - 98), 5)
    if u > 0.72:
        g.txt('trim trim!', x + 20, SY + 40, 24 + int(4 * math.sin(u * 40)), '#7a4a2a', True, True)
        g.txt('Sua bicicleta!', SX + SW // 2, SY + 255, 18, '#4a3a2a', True, True)


def estoque(g, u, arg):
    fundo(g, '#2f4a50')
    g.rect((SX + 150, SY + 170, 390, 14), '#8a6f55', 3)
    g.rect((SX + 150, SY + 90, 390, 14), '#8a6f55', 3)
    cont = 0
    for i in range(10):
        t = clamp((u - 0.04 - i * 0.075) / 0.2)
        if t <= 0:
            continue
        e = ease(t)
        col, lin = i % 5, i // 5
        px = SX + 170 + col * 72
        py = lerp(SY - 20, SY + 126 if lin == 0 else SY + 46, e)
        if t >= 1:
            cont += 1
        g.rect((px, py, 56, 44), '#c8975a', 4)
        g.rect((px + 20, py, 16, 44), '#e4c28a')
    g.txt('Estoque: %d/10' % cont, SX + SW // 2, SY + 235, 22, '#f5dfaa', True, True)


def vender(g, u, arg):
    q = max(1, min(arg.get('qtd', 3), 6))
    fundo(g, '#d6e3e0')
    g.rect((SX, SY + 232, SW, 48), '#a89f84')
    for i in range(8):
        g.rect((SX + 255 + i * 32, SY + 60, 32, 36), '#c0584e' if i % 2 == 0 else '#f4efd9')
    g.rect((SX + 270, SY + 150, 220, 82), '#d9a86b', 4)
    g.rect((SX + 380, SY + 110, 60, 40), '#33474f', 4)
    vendidas = 0
    for i in range(q):
        ini = 0.04 + i * (0.8 / q)
        t = clamp((u - ini) / 0.2)
        sai = clamp((u - ini - 0.24) / 0.16)
        if t >= 1:
            vendidas += 1
        if t <= 0 or sai >= 1:
            continue
        x = lerp(SX + 20, SX + 215, ease(t)) + sai * 300
        cor = ['#8c709f', '#ae7858', '#4e8ba3', '#a56a6a', '#6a9a78', '#b59a4a'][i % 6]
        g.circ('#f0d2b0', (x, SY + 150), 14)
        g.rect((x - 14, SY + 164, 28, 50), cor, 6)
        if 0.6 < t <= 1 and sai == 0:
            g.circ('#e0b45a', (lerp(x + 14, SX + 410, (t - 0.6) / 0.4), SY + 140 - math.sin((t - 0.6) / 0.4 * math.pi) * 30), 8)
    g.txt('Vendas: %d' % vendidas, SX + 110, SY + 30, 22, '#33474f', True, True)


CENAS = {'work': trabalhar, 'sleep': dormir, 'pay': pagar, 'shop': comprar, 'bank': banco,
         'bike': bicicleta, 'stock': estoque, 'sell': vender}

TITULOS = {'work': 'No computador', 'sleep': 'Hora de dormir', 'pay': 'Pagando a conta', 'shop': 'Fazendo compras',
           'bank': 'No guichê do banco', 'bike': 'Nova bicicleta', 'stock': 'Recebendo estoque', 'sell': 'Atendendo clientes'}


def legenda(kind, u):
    f = {'work': [(.18, 'Ligando o computador…'), (.92, 'Trabalhando…'), (2, 'Expediente registrado.')],
         'sleep': [(.62, 'Dormindo…'), (2, 'Um novo dia começa!')],
         'pay': [(.7, 'Preenchendo o pagamento…'), (2, 'Pagamento confirmado.')],
         'shop': [(.7, 'Passando as compras no caixa…'), (2, 'Compras guardadas na despensa.')],
         'bank': [(.8, 'Fazendo a transferência…'), (2, 'Operação concluída.')],
         'bike': [(.7, 'Escolhendo e testando…'), (2, 'Negócio fechado!')],
         'stock': [(.85, 'Descarregando o lote…'), (2, 'Estoque pronto para vender.')],
         'sell': [(.85, 'Clientes chegando ao quiosque…'), (2, 'Fim do expediente de vendas.')]}[kind]
    for lim, texto in f:
        if u < lim:
            return texto
    return f[-1][1]


def desenhar(g, kind, u, arg):
    CENAS[kind](g, clamp(u), arg)
