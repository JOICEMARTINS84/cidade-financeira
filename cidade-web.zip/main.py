import os, math, random, sqlite3, sys, struct, wave, io, json
from iso import project, direction, depth, LOTS, DOORS
from campanha import METAS, perguntas, correto
from orientacao import passos, LOCAIS as DESTINOS
from fluxo_metas import proxima_meta, pendentes, primeiro_calculo, confirmar, continuar
from minijogos import JOGOS, LOCAIS, escolha_correta, indicador, selecionar, erro_estrategia, DICA_CALCULO, XP as XP_MINI
from pathlib import Path
import pygame as pg
from economia import Economia, brl, HORAS_DIA
import animacoes as an
import expansao as ex

W,H=1100,700
pg.init(); pg.display.set_caption('Cidade Financeira V10 | Matemática & Contexto')
window=pg.display.set_mode((W,H))
screen=pg.Surface((W,H)); clock=pg.time.Clock()
fonts={}
def font(n,b=False):
 n=n+2 if globals().get('contraste',False) else n
 k=(n,b)
 if k not in fonts: fonts[k]=pg.font.Font(None,n+2); fonts[k].set_bold(b)
 return fonts[k]
def txt(t,x,y,n=18,c='#e7eef0',bold=False,center=False):
 c='#ffffff' if globals().get('contraste',False) and c not in ('#2a2113','#314839') else c
 im=font(n,bold).render(str(t),True,c); screen.blit(im,im.get_rect(center=(x,y)) if center else (x,y))
def rect(r,c,rad=0,surf=None): pg.draw.rect(screen if surf is None else surf,c,pg.Rect(r),border_radius=rad)
def circ(c,pos,r,surf=None): pg.draw.circle(screen if surf is None else surf,c,tuple(map(int,pos)),r)
def line(c,a,b,w=1,surf=None): pg.draw.line(screen if surf is None else surf,c,a,b,w)
def wrap(t,n,width):
 out=[]; buff=''
 for word in t.split():
  trial=(buff+' '+word).strip()
  if buff and font(n).size(trial)[0]>width: out.append(buff); buff=word
  else: buff=trial
 if buff: out.append(buff)
 return out

base=Path(getattr(sys,"_MEIPASS",Path(__file__).resolve().parent))
save=Path(os.getenv('CIDADE_SAVE_DIR', str(Path(os.getenv('LOCALAPPDATA',str(Path.home())))/'CidadeFinanceira'))); save.mkdir(parents=True,exist_ok=True)
# Copy previous save once, so the V2 remains independently playable.
old_db=save/'cidade.sqlite3'; new_db=save/'cidade_v3.sqlite3'
if old_db.exists() and not new_db.exists():
 with sqlite3.connect(old_db) as src, sqlite3.connect(new_db) as dst: src.backup(dst)
if new_db.exists() and not (save/'cidade_v3_pre_v4.sqlite3').exists():
 with sqlite3.connect(new_db) as src, sqlite3.connect(save/'cidade_v3_pre_v4.sqlite3') as dst: src.backup(dst)
def abrir_save(path):
 if path.exists():
  backup=path.with_name(path.stem+'_pre_v10.sqlite3')
  with sqlite3.connect(path) as src:
   cols={r[1] for r in src.execute('PRAGMA table_info(jogador)')}
   if cols and 'nome' not in cols and not backup.exists():
    with sqlite3.connect(backup) as dst: src.backup(dst)
 return Economia(path)
perfil=1; eco=abrir_save(new_db)
view='inicio'; menu_page=0; meta=0; qidx=0; resposta_texto=''; feedback=''; desafio=None; bonus_text=''; bonus_result=None; resposta_ok=None; contraste=False; mudo=False; final_exibido=False; budget=[]; budget_page=0
mini=None; mini_etapa=0; mini_escolhas=set(); mini_texto=''; mini_feedback=''; mini_xp=0
nome_edicao=''; tipo_edicao='homem'; perfil_retorno='inicio'; area_ind=0; exp_acao=None; exp_texto=''; exp_feedback=''; exp_ok=None

def trocar_perfil(n):
 global perfil,eco,final_exibido,view,meta,qidx,resposta_texto,feedback,resposta_ok,desafio,bonus_result
 eco.db.close(); perfil=n; eco=abrir_save(new_db if n==1 else save/f'cidade_v3_perfil{n}.sqlite3'); final_exibido=bool(eco.estado['finalizado']); meta=0; qidx=0; resposta_texto=''; feedback=''; resposta_ok=None; desafio=None; bonus_result=None; leave_room(); p.update(154,288); view='inicio'

# Retângulos no mapa, cor do telhado, rótulo, ponto de entrada
places={k:(pg.Rect(*r),'#637e76',{'casa':'CASA','mercado':'SUPERMERCADO','empresa':'EMPRESA','banco':'BANCO','loja':'BICICLETARIA','negocio':'QUIOSQUE'}[k],DOORS[k]) for k,r in LOTS.items()}
intro={'casa':'Cuide da sua rotina e das despesas fixas.','mercado':'Compare os preços e abasteça sua despensa.','empresa':'Trabalhe e administre a sua energia.','banco':'Organize sua reserva financeira.','loja':'Compare o preço à vista e parcelado.','negocio':'Administre seu próprio comércio.'}
assets=base/'assets'
def load(name,size): return pg.transform.smoothscale(pg.image.load(str(assets/name)).convert_alpha(),size)
world=load('iso_ground.png',(W,H))
iso_layers=[(v['depth'],pg.image.load(str(assets/v['file'])).convert_alpha(),(v['x'],v['y']),v['name'],pg.Rect(*[v['box'][0],v['box'][1],v['box'][2]-v['box'][0],v['box'][3]-v['box'][1]])) for v in json.loads((assets/'iso_layers.json').read_text(encoding='utf-8'))]
rooms={k:load(k+'.png',(672,492)) for k in places}
distrito_arte={a[0]:load('distrito_'+a[0]+'.png',(150,80)) for a in ex.AREAS}
frames={(d,i):load(f'player_{d}_{i}.png',(40,56)) for d in ['up','down','left','right'] for i in range(3)}
frames_mulher={(d,i):load(f'mulher_{d}_{i}.png',(40,56)) for d in ['up','down','left','right'] for i in range(3)}
def jogador_frames(tipo=None): return frames_mulher if (tipo or eco.estado['personagem'])=='mulher' else frames
p=pg.Vector2(154,288); face='down'; moving=False; anim=0; scene=None; message=''; good=True; showlog=False; reset_confirm=False
roompos=pg.Vector2(84,117); talking=False
job=None; toast=('',True,0.0); menu_keys=None; menu_title=''; menu_dialog=''
# Coordinates in original interior artwork, scaled four times in the game.
room_origin=pg.Vector2(76,112)
room_specs={
 'casa': ([(10,43,44,54),(76,74,71,33),(107,39,50,13)],(65,69),'Agenda da casa','Cuide do seu descanso, da alimentação e do aluguel.'),
 'mercado': ([(6,30,64,30),(97,30,65,30),(6,72,50,30),(107,69,55,19)],(84,82),'Lia • caixa','Compare os preços. Nem sempre a maior cesta é a mais cara por unidade!'),
 'empresa': ([(10,39,61,25),(94,39,61,25),(10,78,61,25),(94,78,61,25)],(82,68),'Rafael • gerente','Escolha sua profissão. Salário, tempo e energia têm um preço.'),
 'banco': ([(9,62,150,13),(18,31,34,26),(121,31,34,26),(62,87,44,20)],(50,81),'Clara • gerente','Separe uma reserva para emergências e planeje seus gastos.'),
 'loja': ([(9,53,52,25),(9,91,52,25),(100,53,52,25),(107,91,54,13)],(83,83),'Davi • vendedor','Compare o custo total de pagar à vista ou em parcelas.'),
 'negocio': ([(6,30,64,30),(97,30,65,30),(10,77,38,16),(107,69,55,19)],(84,80),'Bia • fornecedora','Compre estoque, escolha preços e observe a procura. Receita não é lucro!'),
}

# Estações interativas: (ponto na sala, rótulo, ações). Um brilho no chão marca cada uma.
stations={
 'casa':[((32,103),'Dormir na cama',['dormir']),((78,108),'Sofá',['sofa']),((132,60),'Mesa de contas',['aluguel'])],
 'mercado':[((38,66),'Prateleiras',['cesta1','cesta2']),((98,66),'Ofertas do dia',['promo'])],
 'empresa':[((40,71),'Computador',['turno4','turno2']),((126,71),'Computador',['turno4','turno2']),((40,110),'Computador',['turno4','turno2']),((126,110),'Computador',['turno4','turno2'])],
 'banco':[((125,84),'Guichê',['guardar200','guardar500','resgatar'])],
 'loja':[((30,84),'Testar bicicleta',['vista','prazo']),((130,82),'Vitrine',['vista','prazo'])],
 'negocio':[((29,102),'Caixas de estoque',['comprar']),((134,96),'Balcão de vendas',['vender']),((38,66),'Placa de preços',['preco10','preco12','preco15'])],
}
ANIM={'turno4':'work','turno2':'work','dormir':'sleep','aluguel':'pay','cesta1':'shop','cesta2':'shop','promo':'shop','guardar200':'bank','guardar500':'bank','resgatar':'bank','vista':'bike','prazo':'bike','comprar':'stock','vender':'sell'}
class G: pass
g=G()
_spr={}
def _sprite(face,scale=3):
 k=(face,scale,eco.estado['personagem'])
 if k not in _spr: _spr[k]=pg.transform.scale(jogador_frames()[face,0],(40*scale,56*scale))
 return _spr[k]
g.rect=lambda r,c,rad=0: rect(r,c,rad); g.circ=lambda c,pos,r: circ(c,pos,r); g.line=lambda c,a,b,w=1: line(c,a,b,w)
g.txt=txt; g.polygon=lambda c,pts: pg.draw.polygon(screen,c,pts); g.ellipse=lambda c,r: pg.draw.ellipse(screen,c,pg.Rect(r))
g.sprite=_sprite; g.blit=lambda s,pos: screen.blit(s,pos)

def room_point(pt): return room_origin+pg.Vector2(pt)*4
def close_npc(): return scene and roompos.distance_to(room_specs[scene][1])<18
def target():
 if not scene: return None
 best=None; bd=1e9
 if close_npc(): best=('npc',None); bd=roompos.distance_to(room_specs[scene][1])
 for st in stations[scene]:
  d=roompos.distance_to(st[0])
  if d<12 and d<bd: best=('st',st); bd=d
 return best
def all_opts():
 o=eco.opcoes(scene); return o if menu_keys is None else [x for x in o if x[0] in menu_keys]
def cur_opts():
 o=all_opts(); return o[menu_page*5:menu_page*5+5]
def say(text,ok=True): 
 global toast; toast=(text,ok,4.5)
def start_job(key,msg):
 global job
 kind=ANIM[key]; arg={}
 if kind=='work': arg['horas']=4 if key=='turno4' else 2
 elif kind=='shop': arg['itens']=3 if key=='cesta1' else 6; arg['promo']=key=='promo'
 elif kind=='bank': arg['saindo']=key=='resgatar'; arg['moedas']=5 if key=='guardar500' else 2
 elif kind=='sell':
  try: arg['qtd']=int(msg.split()[0])
  except ValueError: arg['qtd']=3
 job={'kind':kind,'t':0.0,'dur':an.DURACAO,'arg':arg,'msg':msg,'ok':True,'key':key}
def run(key):
 global message,good,menu_page
 antes=eco.concluidas(); good,message=eco.agir(scene,key)
 novas=eco.concluidas()-antes
 if good and novas: message+=' | Meta concluída: '+', '.join(METAS[i][0] for i in sorted(novas))+'!'
 elif good:
  i=proxima_meta(eco)
  if i is not None and eco.progresso(i)['acao']: message+=' | Ação OK. F: cálculos da meta.'
 menu_page=min(menu_page,max(0,(len(all_opts())-1)//5))
 beep(good)
 if good and key in ANIM: start_job(key,message)
 else: say(message,good)
def open_menu(keys,title,dialog):
 global talking,message,menu_keys,menu_title,menu_dialog,menu_page
 menu_page=0; talking=True; message=''; menu_keys=keys; menu_title=title; menu_dialog=dialog
def close_menu():
 global talking,message,menu_keys
 talking=False; message=''; menu_keys=None
def use_station(st):
 pt,label,keys=st
 opts=[o for o in eco.opcoes(scene) if o[0] in keys]
 if not opts: say('Fale com '+room_specs[scene][2].split('•')[0].strip()+' primeiro.',False)
 elif len(opts)==1: decidir(opts[0][0])
 else: open_menu(keys,label,'Escolha o que fazer aqui.')

def room_allowed(pt):
 if not (7<pt.x<161 and 41<pt.y<120): return False
 hit=pg.Rect(pt.x-2.5,pt.y-2,5,4)
 return not any(hit.colliderect(pg.Rect(*r)) for r in room_specs[scene][0]) and pt.distance_to(room_specs[scene][1])>4

def avatar(x,y,phase,face='down',shirt=None,walk=True,player=False):
 if face in (1,-1): face='right' if face==1 else 'left'
 frame=([1,0,2,0][int(phase)%4] if walk else 0)
 sprite=(jogador_frames() if player else frames)[face,frame]
 if shirt:
  sprite=sprite.copy(); mask=pg.PixelArray(sprite)
  mask.replace(pg.Color('#8164ab' if player and eco.estado['personagem']=='mulher' else '#4e8ba3'),pg.Color(shirt),distance=.08); del mask
 screen.blit(sprite,(int(x)-20,int(y)-49))

def nearest():
 return min(places,key=lambda k:p.distance_to(places[k][3])) if min(p.distance_to(v[3]) for v in places.values())<52 else None

def panel(r): rect((r[0]+4,r[1]+6,r[2],r[3]),'#101010',10); rect(r,'#202020',10); pg.draw.rect(screen,'#c0a975',r,width=2,border_radius=10)
def button(r,title,sub,idx):
 rect(r,'#303030',10); rect((r[0]+13,r[1]+12,33,33),'#d9ba75',7); txt(str(idx+1),r[0]+29,r[1]+28,19,'#2a2113',True,True); txt(title,r[0]+60,r[1]+8,21,'#f4efd9',True); txt(sub,r[0]+60,r[1]+31,16,'#c0d0cf')
def choose(i):
 opts=cur_opts()
 if 0<=i<len(opts): decidir(opts[i][0])

def draw_room(s):
 rect((0,100,W,520),'#151515'); rect((68,104,688,508),'#b6a16d',6); screen.blit(rooms[scene],(76,112))
 obs,npc,name,dialog=room_specs[scene]; nx,ny=room_point(npc)
 if scene=='casa':
  rect((nx-15,ny-24,30,25),'#634c3f',3); rect((nx-10,ny-21,20,17),'#f5e0b5',2); line('#997e61',(nx-6,ny-15),(nx+6,ny-15),2)
 else: avatar(nx,ny,0,'down','#ad795a',False)
 for st in stations[scene]:
  sx,sy=room_point(st[0]); pg.draw.circle(screen,'#f3d584',(int(sx),int(sy)),int(7+2*math.sin(pg.time.get_ticks()/250)),2)
 px,py=room_point(roompos); avatar(px,py,anim,face,'#639c78' if s['roupa_equipada'] else None,moving,True)
 tg=target()
 if tg and not talking and not job:
  if tg[0]=='npc': tx,ty,tl=nx,ny-69,'E  •  Conversar'
  else: tx,ty=room_point(tg[1][0]); ty-=75; tl='E  •  '+tg[1][1]
  tw=max(150,font(14,True).size(tl)[0]+24); rect((max(78,min(740-tw,tx-tw/2)),ty,tw,25),'#252525',5); txt(tl,max(78+tw/2,min(740-tw/2,tx)),ty+12,14,'#f4e1ab',True,True)
 if toast[2]>0 and not job:
  ls=wrap(toast[0],15,620)[:3]; bh=14+20*len(ls); rect((86,596-bh,652,bh),'#1d1d1d',8); pg.draw.rect(screen,'#b5dfa8' if toast[1] else '#f6b7a7',(86,596-bh,652,bh),width=2,border_radius=8)
  for j,v in enumerate(ls): txt(v,100,596-bh+7+j*20,15,'#b5dfa8' if toast[1] else '#f6b7a7',True)
 rect((770,112,316,492),'#262626',10); txt(places[scene][2],790,132,25,'#f1d7a2',True)
 txt(name,790,181,18,'#edf0dc',True)
 for i,v in enumerate(wrap(dialog,18,270)): txt(v,790,215+i*25,18,'#c5d9d2')
 yy=327
 if scene=='negocio':
  for label,val in [('Estoque',str(s['estoque'])+' un.'),('Preço',brl(s['preco'])),('Receita acumulada',brl(s['receita'])),('Resultado c/ investimento',brl(s['lucro']))]:
   txt(label,790,yy,14,'#aac5c2'); txt(val,790,yy+18,21,'#f2e7ce',True); yy+=52
 elif scene=='empresa':
  for v in wrap('Profissão: '+(s['profissao'] or 'Ainda não contratado'),19,270): txt(v,790,yy,19,'#f0d6a3',True); yy+=25
  txt(f"Horas hoje: {s['turnos']}/{HORAS_DIA}",790,yy+17,19)
 else:
  txt('Explore o ambiente.',790,350,18,'#f0d6a3',True); txt('Aproxime-se e pressione E.',790,378,16,'#c5d9d2')
 # Visible exit tile, positioned below all furnishings.
 ex,ey=room_point((84,118)); rect((ex-28,ey-6,56,10),'#647e65',2); txt('SAÍDA',ex,ey-13,11,'#314839',True,True)
 if talking:
  shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((0,0,0,160)); screen.blit(shade,(0,0)); panel((180,110,740,498))
  txt(menu_title or name,205,125,27,'#f4dfad',True)
  for j,v in enumerate(wrap(menu_dialog or dialog,16,680)): txt(v,205,164+j*20,16,'#c6d8d4')
  for i,(key,title,sub) in enumerate(cur_opts()): button((205,207+i*59,690,54),title,sub,i)
  if message:
   for j,v in enumerate(wrap(message,14,680)[:2]): txt(v,205,505+j*17,14,'#b5dfa8' if good else '#f6b7a7',True)
  txt(f'Página {menu_page+1}/{max(1,(len(all_opts())+4)//5)}',205,548,12,'#a9c2c6')
 if job:
  shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((0,0,0,200)); screen.blit(shade,(0,0)); panel((180,110,740,498))
  txt(an.TITULOS[job['kind']],205,125,27,'#f4dfad',True)
  an.desenhar(g,job['kind'],job['t']/job['dur'],job['arg'])
  txt(an.legenda(job['kind'],job['t']/job['dur']),550,462,20,'#f4efd9',True,True)
  txt('E / ESPAÇO: pular',205,578,15,'#a9c2c6')

ui_clicks=[]
def control(r,label,key,sub='',active=False):
 r=pg.Rect(r); hover=r.collidepoint(logical(pg.mouse.get_pos())); rect(r,'#4b3c22' if hover or active else '#292929',7)
 pg.draw.rect(screen,'#ebca80' if hover or active else '#6a5836',r,1,border_radius=7)
 txt(label,r.centerx,r.y+(15 if sub else r.h//2),15,'#f5edda',True,True)
 if sub: txt(sub,r.centerx,r.y+32,12,'#b1c8bf',False,True)
 ui_clicks.append((r,key))
def barra(x,y,w,frac,color):
 rect((x,y,w,7),'#424242',4); amount=max(0,min(w,int(w*frac)))
 if amount: rect((x,y,amount,7),color,4)
def iso_avatar(x,y,phase,f='down',shirt=None,walk=True,player=False):
 sx,sy=project(x,y); frame=[1,0,2,0][int(phase)%4] if walk else 0
 key=(f,frame,shirt,eco.estado['personagem'] if player else 'npc')
 if key not in iso_people:
  sp=(jogador_frames() if player else frames)[f,frame].copy()
  if shirt:
   mask=pg.PixelArray(sp); mask.replace(pg.Color('#8164ab' if player and eco.estado['personagem']=='mulher' else '#4e8ba3'),pg.Color(shirt),distance=.08); del mask
  iso_people[key]=pg.transform.smoothscale(sp,(25,35))
 return iso_people[key],(int(sx)-12,int(sy)-30)
iso_people={}
def car_sprite(color,flip=False):
 k=(color,flip)
 if k in cars: return cars[k]
 # Smooth vector car in the same screen direction as the road.
 surf=pg.Surface((96,48),pg.SRCALPHA); pg.draw.ellipse(surf,(27,43,46,75),(4,28,85,14))
 pg.draw.rect(surf,'#273840',(15,27,15,11),border_radius=4); pg.draw.rect(surf,'#273840',(66,27,15,11),border_radius=4)
 pg.draw.rect(surf,color,(4,16,88,18),border_radius=8); pg.draw.polygon(surf,color,[(21,17),(36,5),(63,5),(78,17)])
 pg.draw.polygon(surf,'#4e7488',[(28,16),(38,7),(48,7),(48,16)]); pg.draw.polygon(surf,'#6496a8',[(52,7),(61,7),(71,16),(52,16)])
 pg.draw.line(surf,'#d5e0d8',(23,19),(75,19),2); pg.draw.rect(surf,'#fff0b9',(83,20,6,5),border_radius=2); pg.draw.rect(surf,'#9e4f46',(5,20,5,5),border_radius=2)
 if flip: surf=pg.transform.flip(surf,True,False)
 surf=pg.transform.rotozoom(surf,-14,.38); cars[k]=surf; return surf
cars={}
def draw_city(s,prox,pendente_acao):
 t=pg.time.get_ticks()/1000
 layers=[(dep,sprite,pos) for dep,sprite,pos,_,_ in iso_layers]
 for i,(a,b,y,shirt) in enumerate([(14,1080,296,'#ae7858'),(1080,14,410,'#8c709f'),(14,1080,410,'#6b9b79'),(1080,14,296,'#b5a16f'),(14,1080,586,'#9b7da2')]):
  xx=a+(b-a)*((t*.035+i*.42)%1); sprite,pos=iso_avatar(xx,y,t*8,'right' if b>a else 'left',shirt)
  layers.append((depth(xx,y),sprite,pos))
 for i,(color,y) in enumerate([('#d9a969',331),('#a3c5d4',371),('#db8b82',331)]):
  xx=((t*(56 if y==331 else -49)+i*390)%1070)+15; sx,sy=project(xx,y); sp=car_sprite(color,y==371); layers.append((sy,sp,sp.get_rect(center=(int(sx),int(sy)-3)).topleft))
 for key,door in DOORS.items():
  x,y=project(*door); circ('#f2cc72',(x,y),5); circ('#447c73',(x,y),2)
 sprite,pos=iso_avatar(p.x,p.y,anim,face,'#639c78' if s['roupa_equipada'] else None,moving,True)
 if s['bicicleta'] and moving:
  bike=pg.Surface((40,27),pg.SRCALPHA); pg.draw.circle(bike,'#304049',(8,17),7,2); pg.draw.circle(bike,'#304049',(30,17),7,2); pg.draw.lines(bike,'#e1af55',False,[(8,17),(18,7),(22,17),(8,17),(30,17),(25,5)],2); layers.append((depth(p.x,p.y)-.1,bike,(int(project(*p)[0])-19,int(project(*p)[1])-19)))
 layers.append((depth(p.x,p.y)+.1,sprite,pos))
 for _,sp,pos in sorted(layers,key=lambda a:a[0]): screen.blit(sp,pos)
 destinos=('empresa','casa','mercado','mercado','banco','loja','empresa','banco','banco','banco','mercado','empresa','negocio','negocio',None)
 if prox is not None and pendente_acao and destinos[prox]:
  dx,dy=project(*DOORS[destinos[prox]]); pg.draw.circle(screen,'#ffe2a1',(int(dx),int(dy)),int(8+2*math.sin(t*4)),2)
  pg.draw.polygon(screen,'#ffd56b',[(dx,dy-9),(dx-6,dy-20),(dx+6,dy-20)])
 if s['hora']>=17:
  shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((14,25,74,55 if s['hora']<19 else 125)); screen.blit(shade,(0,0))
 if eco.clima(s)=='Chuva':
  for j in range(85):
   x=(j*131+int(t*140))%W; y=120+(j*73+int(t*390))%480; line('#90b4ca',(x,y),(x-5,y+12),1)
def fit_text(v,x,y,w,n=18,c='#f5edda',bold=False):
 v=str(v)
 while n>10 and font(n,bold).size(v)[0]>w: n-=1
 if font(n,bold).size(v)[0]>w:
  while v and font(n,bold).size(v+'…')[0]>w: v=v[:-1]
  v+='…'
 txt(v,x,y,n,c,bold)

def city_hud(s,prox,feitas):
 rect((0,0,W,88),'#111111'); rect((0,86,W,2),'#b99852')
 txt('CIDADE',14,11,24,'#ffffff',True); txt('FINANCEIRA',14,36,24,'#e4c16d',True); txt('MATEMÁTICA & CONTEXTO',15,66,9,'#d1c5ac',True)
 pg.draw.line(screen,'#66562f',(185,9),(185,78),1)
 rect((197,8,54,69),'#292929',8); screen.blit(pg.transform.smoothscale(jogador_frames()['down',0],(46,64)),(201,10))
 fit_text(s['nome'] or 'Seu personagem',260,11,120,18,'#ffffff',True)
 nivel=1+s['xp']//200; txt(f'Nível {nivel}  •  {s["xp"]} XP',260,35,12,'#d7c9ab',True); barra(260,58,119,(s['xp']%200)/200,'#d9b45c')
 for x,w,label,value in [(392,141,'CARTEIRA',brl(s['saldo'])),(540,133,'RESERVA',brl(s['reserva'])),(680,142,'INVESTIMENTOS',brl(s['cdb']+s['acoes']*ex.preco(s['dia']))),(829,126,'ENERGIA / COMIDA',f"{s['energia']}% • {s['comida']}")]:
  rect((x,9,w,69),'#232323',7); txt(label,x+9,17,11,'#d4c6a7',True); fit_text(value,x+9,39,w-18,20,'#bce5ad' if label=='CARTEIRA' else '#ffffff',True)
 txt(f'Dia {s["dia"]:02d}',969,11,18,'#f5e2ad',True); txt(f'{s["hora"]:02d}:00  •  {eco.clima(s)}',969,36,13); txt(f'{len(feitas)+len(eco.metas_expansao())}/21 metas',969,60,12,'#d4c6a7')
 if not scene:
  rect((8,101,137,343),'#141414',10); pg.draw.rect(screen,'#806b3d',(8,101,137,343),1,border_radius=10)
  for i,(label,key) in enumerate([('Cidade',pg.K_F2),('Missões',pg.K_m),('Finanças',pg.K_F3),('Inventário',pg.K_F4),('Aprendi hoje',pg.K_l),('Ranking',pg.K_F5),('Opções',pg.K_p)]):
   control((15,109+i*46,123,40),label,key,active=i==0)
  control((15,455,123,39),'Interagir [E]',pg.K_e)
  control((15,501,123,39),'Minijogos [G]',pg.K_g)
  control((15,547,123,39),'Distrito [N]',pg.K_n,active=True)
  # Right column follows the approved reference: current mission, then learning note.
  rect((866,101,226,357),'#151515',10); pg.draw.rect(screen,'#9f8146',(866,101,226,357),1,border_radius=10)
  txt('MISSÃO ATUAL',880,113,18,'#e7c16e',True)
  if prox is None: txt('15/15 metas concluídas!',878,153,16,'#bce5ad',True)
  else:
   pr=eco.progresso(prox,s); m=METAS[prox]; y=148
   for v in wrap(f'{prox+1:02d}. {m[0]}',18,198)[:3]: txt(v,878,y,18,'#ffffff',True); y+=23
   y+=8
   txt('Progresso da missão',878,y,12,'#c7b999'); y+=20
   ac=min(8,pr['horas'])/8 if prox==0 else int(pr['acao']); barra(878,y,200,ac,'#8fc58c'); y+=15
   for v in wrap(passos(eco,prox)[0],13,198)[:3]: txt(v,878,y,13,'#bce5ad' if pr['acao'] else '#ead9b8'); y+=17
   y+=7; txt(f'Cálculos: {pr["acertos"]}/{pr["total"]}',878,y,15,'#ffffff',True); y+=22; barra(878,y,200,pr['acertos']/pr['total'],'#e4bf78'); y+=16
   txt('BNCC • '+m[1 if s['nivel']=='EF' else 2],878,y,13,'#d4c6a7',True)
   control((878,408,202,39),'Resolver cálculos [F]',pg.K_f,active=True)
  rect((866,470,226,143),'#151515',10); pg.draw.rect(screen,'#9f8146',(866,470,226,143),1,border_radius=10)
  txt('APRENDI HOJE',878,482,16,'#e7c16e',True)
  for j,v in enumerate(wrap(s['aprendi'] or 'Realize uma ação para registrar sua aprendizagem.',14,199)[:5]): txt(v,878,509+j*18,14,'#eeeeee')
 rect((0,622,W,78),'#111111'); rect((0,622,W,2),'#b99852')
 for i,(label,key,sub) in enumerate([('Agenda',pg.K_m,'Metas'),('Orçamento',pg.K_o,'Receitas / despesas'),('Cartão',pg.K_F6,'Crédito'),('Empréstimo',pg.K_F7,'Dívidas'),('Investimentos',pg.K_F8,'Banco'),('Meu quiosque',pg.K_F9,'Negócio'),('Carreira',pg.K_F10,'Emprego'),('Conquistas',pg.K_F12,'Progresso')]):
  control((8+i*136,632,130,53),label,key,sub)
 if scene: control((12,93,120,25),'Voltar à cidade',pg.K_F2)

def draw():
 global screen
 ui_clicks.clear(); s=eco.estado; feitas=eco.concluidas(); prox=proxima_meta(eco)
 pendente_acao=prox is not None and not eco.progresso(prox,s)['acao']
 if not scene:
  original=screen; screen=pg.Surface((W,H)); screen.blit(world,(0,0)); draw_city(s,prox,pendente_acao)
  n=nearest()
  if n:
   px,py=project(*p); lx=max(104,min(W-104,px)); ly=max(119,py-57); rect((lx-103,ly-15,206,30),'#222222',10); txt('E  •  '+places[n][2],lx,ly,17,'#f4e5b9',True,True)
  mapa=screen; screen=original; screen.fill('#151515'); rect((149,94,713,524),'#202020',8)
  screen.blit(pg.transform.smoothscale(mapa,(709,451)),(151,124))
  txt('CIDADE  /  explore com WASD ou setas',165,103,13,'#d4c6a7',True)
  if n: txt('E ou Interagir: '+places[n][2],165,586,16,'#f4e5b9',True)
  else: txt('Aproxime-se das entradas para explorar os estabelecimentos.',165,586,14,'#d4c6a7')
 else:
  screen.blit(world,(0,0)); draw_room(s)
 city_hud(s,prox,feitas)
 # Mensagem breve, sem cobrir as fachadas.
 if not scene and not view and toast[2]>0:
  lines=wrap(toast[0],15,540)[:2]; rect((278,425,548,25+len(lines)*19),'#252525',8)
  for j,l in enumerate(lines): txt(l,290,436+j*19,15,'#bce5ad' if toast[1] else '#f6b7a7')
 if showlog or reset_confirm: ui_clicks.clear()
 if showlog or reset_confirm:
  shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((0,0,0,175)); screen.blit(shade,(0,0)); panel((205,124,690,455))
  if showlog:
   txt('EXTRATO',235,147,32,'#f4dfad',True); txt(f"Saldo líquido: {brl(eco.patrimonio(s))} (inclui estoque; sem bicicleta)",235,195,19,'#c8dbd2')
   txt(f"Dívidas totais: {brl(eco.divida(s))}",235,223,17,'#c8dbd2')
   for i,row in enumerate(eco.historico()):
    yy=262+i*29; txt(f"Dia {row['dia']:02d}  ·  {row['descricao']}",235,yy,16); txt(brl(row['variacao']),697,yy,16,'#b5dfa8' if row['variacao']>=0 else '#f6b7a7')
   control((235,532,275,36),'Reiniciar jogo',pg.K_r); control((612,532,250,36),'Fechar extrato',pg.K_ESCAPE)
  else:
   txt('RECOMEÇAR?',235,170,32,'#f4dfad',True); txt('Isso apaga o progresso salvo neste computador.',235,240,21); txt('S — confirmar     ESC — cancelar',235,310,22,'#f4dfad',True)

 if talking or job: ui_clicks.clear()
 if talking and not job:
  control((205,562,130,28),"Anterior",pg.K_PAGEUP); control((346,562,130,28),"Mais opções",pg.K_PAGEDOWN); control((487,562,130,28),"Minijogos",pg.K_g); control((628,562,267,28),"Fechar",pg.K_ESCAPE)
 if view or desafio: draw_overlay(s)

def hit(pt): return pg.Rect(pt[0]-10,pt[1]-8,20,18)
def allowed(pt): return 14<pt.x<W-14 and 111<pt.y<602 and not any(hit(pt).colliderect(v[0]) for v in places.values())
def logical(pos):
 ww,hh=window.get_size(); sc=min(ww/W,hh/H); return ((pos[0]-(ww-W*sc)/2)/sc,(pos[1]-(hh-H*sc)/2)/sc)
def enter_room(k):
 global scene,talking,message,face
 global menu_keys,job,toast
 scene=k; talking=False; message=''; menu_keys=None; job=None; toast=('',True,0.0); roompos.update(84,116); face='up'
def leave_room():
 global scene,talking,message,face,menu_keys,job
 if scene: p.update(*places[scene][3]); scene=None
 talking=False; message=''; face='down'; menu_keys=None; job=None

web_keys=set()
def frame(dt):
 global scene,talking,message,showlog,reset_confirm,running,moving,anim,face,p,roompos,job,toast,view,menu_page,budget,final_exibido,budget_page,meta,qidx,resposta_texto,feedback
 if eco.estado['finalizado'] and not final_exibido and not job and not view and not desafio:
  view='final'; final_exibido=True
 for e in pg.event.get():
  if e.type==pg.QUIT: running=False
  elif e.type==pg.KEYDOWN:
   if e.key==pg.K_F11: pass  # Fullscreen is handled by the browser.
   elif view or desafio: acionar_overlay(e)
   elif job:
    if e.key in (pg.K_e,pg.K_SPACE,pg.K_RETURN,pg.K_ESCAPE): job['t']=job['dur']
   elif e.key==pg.K_ESCAPE:
    if reset_confirm: reset_confirm=False
    elif showlog: showlog=False
    elif talking: close_menu()
    elif scene: leave_room()
    else: view='pausa'
   elif reset_confirm:
    if e.key==pg.K_s:
     identidade=eco.estado; eco.reset(); eco.personalizar(identidade['nome'],identidade['personagem']); final_exibido=False; reset_confirm=False; leave_room(); p.update(154,288)
   elif showlog:
    if e.key==pg.K_r: showlog=False; reset_confirm=True
    elif e.key==pg.K_TAB: showlog=False
   elif e.key in (pg.K_m,pg.K_f) and not showlog and not reset_confirm:
    if talking: close_menu()
    abrir_meta_atual(e.key==pg.K_f)
   elif e.key==pg.K_n:
    if talking: close_menu()
    view='distrito'
   elif talking:
    if e.key==pg.K_g: close_menu(); view='mini_lista'
    elif pg.K_1<=e.key<=pg.K_5: choose(e.key-pg.K_1)
    elif e.key==pg.K_PAGEDOWN: menu_page=min(menu_page+1,max(0,(len(all_opts())-1)//5))
    elif e.key==pg.K_PAGEUP: menu_page=max(0,menu_page-1)
   elif e.key==pg.K_F2:
    if scene: leave_room()
   elif e.key in PAINEIS: view=PAINEIS[e.key]
   elif e.key==pg.K_g: view='mini_lista'
   elif e.key==pg.K_l: view='aprendi'
   elif e.key==pg.K_o: budget=eco.orcamento(); budget_page=0; view='orcamento'
   elif e.key==pg.K_p: view='pausa'
   elif e.key==pg.K_TAB: showlog=True
   elif e.key==pg.K_e:
    if scene:
     tg=target()
     if tg and tg[0]=='npc': open_menu(None,'',room_specs[scene][3])
     elif tg: use_station(tg[1])
     elif roompos.distance_to((84,118))<12: leave_room()
    elif nearest(): enter_room(nearest())
  elif e.type==pg.MOUSEBUTTONDOWN and e.button==1:
   mx,my=logical(e.pos)
   if (view or desafio) and not job:
    for r,k in ui_clicks:
     if r.collidepoint(mx,my):
      acionar_overlay(pg.event.Event(pg.KEYDOWN,key=k,unicode='')); break
   elif talking and not job and not showlog and not reset_confirm:
    for i in range(len(cur_opts())):
     if pg.Rect(205,207+i*59,690,54).collidepoint(mx,my): choose(i); break
    else:
     for r,k in ui_clicks:
      if r.collidepoint(mx,my): pg.event.post(pg.event.Event(pg.KEYDOWN,key=k,unicode='')); break
   elif not job:
    for r,k in ui_clicks:
     if r.collidepoint(mx,my): pg.event.post(pg.event.Event(pg.KEYDOWN,key=k,unicode='')); break
 physical=pg.key.get_pressed(); keys={k: bool(physical[k] or k in web_keys) for k in (pg.K_d,pg.K_a,pg.K_w,pg.K_s,pg.K_RIGHT,pg.K_LEFT,pg.K_UP,pg.K_DOWN)}; moving=False
 if job:
  job['t']+=dt
  if job['t']>=job['dur']:
   key=job['key']; say(job['msg'],True); job=None
   if key in ('turno2','turno4'):
    pr=eco.progresso(0)
    if not pr['concluida'] and pr['acao'] and pr['acertos']<pr['total']:
     close_menu(); abrir_questao(0); feedback='8 horas cumpridas! Resolva os cálculos restantes.'
    elif not pr['concluida']: say(eco.status_meta(0)+' • M abre a missão',True)
    elif pr['concluida']: pass  # Preserve the result of the actual action.
 elif toast[2]>0: toast=(toast[0],toast[1],toast[2]-dt)
 if not job and not talking and not showlog and not reset_confirm and not view and not desafio:
  d=pg.Vector2(int(keys[pg.K_d] or keys[pg.K_RIGHT])-int(keys[pg.K_a] or keys[pg.K_LEFT]),int(keys[pg.K_s] or keys[pg.K_DOWN])-int(keys[pg.K_w] or keys[pg.K_UP]))
  if d.length_squared():
   moving=True; anim+=dt*15
   if abs(d.x)>abs(d.y): face='right' if d.x>0 else 'left'
   else: face='down' if d.y>0 else 'up'
   if not scene: d=pg.Vector2(direction(d.x,d.y))
   d=d.normalize()*dt*(39 if scene else (210 if eco.estado['bicicleta'] else 155))
   for delta in (pg.Vector2(d.x,0),pg.Vector2(0,d.y)):
    if scene:
     if room_allowed(roompos+delta): roompos+=delta
    elif allowed(p+delta): p+=delta
 draw(); ww,hh=window.get_size(); sc=min(ww/W,hh/H); out=pg.transform.smoothscale(screen,(max(1,int(W*sc)),max(1,int(H*sc)))); window.fill('#101010'); window.blit(out,out.get_rect(center=(ww//2,hh//2))); pg.display.flip()

# Painéis e cálculos da campanha
_sound={}
_music=None
def musica():
 global _music
 if not pg.mixer.get_init(): return
 try:
  if _music is None:
   rate,fmt,channels=pg.mixer.get_init()
   if fmt!=-16: return
   notes=(261.63,329.63,392,329.63,293.66,349.23,440,349.23); dur=.4; count=int(rate*dur)
   raw=b''.join(struct.pack('<h',int(650*math.sin(2*math.pi*f*i/rate)*min(1,i/(rate*.03))*(1-i/count)))*channels for f in notes for i in range(count))
   _music=pg.mixer.Sound(buffer=raw)
  if mudo: _music.stop()
  elif not _music.get_num_channels(): _music.play(loops=-1)
 except pg.error: pass
def beep(ok):
 if mudo or not pg.mixer.get_init(): return
 try:
  if ok not in _sound:
   rate=pg.mixer.get_init()[0]; channels=pg.mixer.get_init()[2]; f=620 if ok else 220
   raw=b''.join(struct.pack('<h',int(2600*math.sin(2*math.pi*f*i/rate)*(1-i/(rate*.12))))*channels for i in range(int(rate*.12)))
   _sound[ok]=pg.mixer.Sound(buffer=raw)
  _sound[ok].play()
 except pg.error: pass

def decidir(key):
 global desafio,bonus_text,feedback,bonus_result
 s=eco.estado; q=None
 if key=='prazo': q=('Qual o custo total de 4 parcelas de R$ 110?',440,'4 × 110 = 440.')
 elif key=='vista': q=('Se a bicicleta custasse R$ 400, com 20% de desconto, quanto economizaria?',80,'400 × 0,20 = 80.')
 elif key=='promo':
  v=eco.precos(s)['cesta2'][0]; q=(f'Qual é 20% de {brl(v)}?',(v-eco.precos(s)['promo'][0])/100,'Calcule o preço original × 0,20 (centavos arredondados).')
 elif key=='emprestar': q=('R$ 500 a 4% por um mês: juros?',20,'500 × 0,04 = 20.')
 elif key=='vender' and s['estoque']:
  n=min(s['estoque'],eco.demanda(s)); q=(f'{n} unidades por {brl(s["preco"])}: receita?',n*s['preco']/100,'Quantidade × preço.')
 if q:
  desafio=(key,q); bonus_text=''; feedback=''; bonus_result=None
 else: run(key)

def modal(title,sub=''):
 ui_clicks.clear(); shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((0,0,0,212)); screen.blit(shade,(0,0)); panel((85,105,930,500)); txt(title,112,124,31,'#f4dfad',True); txt(sub,114,169,17,'#b3d0cf')
def bloco(t,y,n=20,c='#e7eef0'):
 for j,ln in enumerate(wrap(t,n,856)): txt(ln,115,y+j*(n+6),n,c)
def draw_overlay(s):
 if view=='personagem':
  modal('Crie seu personagem','Seu nome e aparência são salvos neste perfil.')
  for i,tipo in enumerate(('homem','mulher')):
   x=170+i*410; rect((x,209,350,181),'#292929' if tipo!=tipo_edicao else '#473a20',10)
   screen.blit(pg.transform.smoothscale(jogador_frames(tipo)['down',0],(80,112)),(x+135,215))
   control((x+40,339,270,43),'Homem' if i==0 else 'Mulher',-300-i,active=tipo==tipo_edicao)
  txt('Nome do personagem (até 24 caracteres)',170,411,18,'#f4dfad',True)
  rect((170,443,760,46),'#303030',6); txt(nome_edicao+'|',186,450,24)
  txt(feedback,170,499,16,'#ffd0c2')
  control((170,545,365,43),'Salvar e continuar',pg.K_RETURN,active=True); control((565,545,365,43),'Voltar',pg.K_ESCAPE); return
 if view in ('financas','inventario','credito','emprestimos','investir','quiosque','carreira','conquistas','ranking_cidade'):
  draw_painel_extra(s); return
 if view in ('distrito','distrito_area','distrito_calculo'):
  draw_distrito(s); return
 if view in ('mini_lista','mini_jogo'):
  draw_mini(); return
 if desafio:
  modal('Desafio antes da decisão','Opcional • acerte para ganhar 10 XP (uma vez por tipo de ação)')
  bloco(desafio[1][0],220,26); rect((115,300,850,54),'#303030',6); txt(bonus_text+('|' if bonus_result is None else ''),130,313,26)
  if bonus_result is not None:
   rect((115,370,850,122),'#284f42' if bonus_result else '#633c39',8); bloco(feedback,382,20,'#bce5ad' if bonus_result else '#ffd0c2')
   control((115,543,415,46),'Continuar com a decisão',pg.K_RETURN,active=True); control((550,543,415,46),'Cancelar decisão',pg.K_ESCAPE)
  else:
   bloco(feedback or 'Treino bônus: não substitui os cálculos obrigatórios da meta.',402,19)
   control((115,543,270,46),'Confirmar resposta',pg.K_RETURN,active=True); control((397,543,270,46),'Pular cálculo e decidir',pg.K_s); control((679,543,286,46),'Cancelar decisão',pg.K_ESCAPE)
  return
 if view in ('inicio','pausa'):
  modal('CIDADE FINANCEIRA • V10',f'Perfil {perfil}  |  {s["nome"] or "Sem nome"}  |  {"Ensino Fundamental II" if s["nivel"]=="EF" else "Ensino Médio"}  |  {len(eco.concluidas())}/15 metas')
  control((114,220,420,52),'Jogar / continuar',pg.K_RETURN,'ENTER',True)
  control((550,220,205,52),'Fundamental II',pg.K_e,'E',s['nivel']=='EF')
  control((769,220,205,52),'Ensino Médio',pg.K_h,'H',s['nivel']=='EM')
  for i in range(4): control((114+i*120,289,110,43),f'Perfil {i+1}',pg.K_1+i,active=perfil==i+1)
  control((604,289,178,43),'Ranking',pg.K_r); control((794,289,180,43),'Tutorial',pg.K_t)
  control((114,350,420,43),'Contraste: '+('alto' if contraste else 'normal'),pg.K_c)
  control((550,350,424,43),'Som: '+('mudo' if mudo else 'ligado'),pg.K_s)
  control((114,410,420,43),'Exportar CSV',pg.K_x); control((550,410,424,43),'Sair',pg.K_q)
  control((114,471,420,44),'Editar personagem / nome',pg.K_j); fit_text(s['nome'] or 'Crie seu personagem antes de começar',550,482,423,17,'#f4dfad',True); bloco(feedback,535,16); return
 if view=='aprendi':
  modal('Aprendi hoje','Seu diário de aprendizagem financeira')
  bloco(s['aprendi'] or 'Realize ações e responda aos desafios para registrar a primeira aprendizagem.',226,24,'#f4dfad')
  control((765,542,200,43),'Voltar',pg.K_ESCAPE); return
 if view=='tutorial':
  modal('Como jogar','15 metas, decisões e cálculos')
  for i,l in enumerate(['1. Use WASD ou setas para andar e E para entrar e interagir.','2. Na empresa, escolha um emprego. Trabalhe e compre alimentos.','3. F abre os cálculos da meta atual; M lista todas as metas.','4. Visite banco, casa, mercado, bicicletaria e quiosque.','5. G: minijogos; N: distrito; O: orçamento; P: pausa.','6. Complete ações e cálculos; chegue a 60 dias com patrimônio e sem dívida.']): bloco(l,215+48*i,20)
  control((765,544,200,42),'Voltar',pg.K_ESCAPE); return
 if view=='metas':
  modal('Campanha • 15 objetivos',f'{len(eco.concluidas())}/15 concluídos • ↑/↓ escolher • ENTER abrir • ESC voltar')
  start=(meta//5)*5
  for i in range(start,min(start+5,15)):
   y=205+(i-start)*70; rect((112,y,870,61),'#4b3c22' if i==meta else '#303030',7)
   txt(f'{i+1:02d}  {METAS[i][0]}   [{METAS[i][1 if s["nivel"]=="EF" else 2]}]',128,y+6,21,'#f5dfaa',True)
   txt(eco.status_meta(i,s)+'  •  '+DESTINOS[i],128,y+35,16)
   ui_clicks.append((pg.Rect(112,y,870,61),(-1000-i)))
  control((112,558,160,36),'Anterior',pg.K_UP); control((285,558,160,36),'Próxima',pg.K_DOWN); control((462,558,270,36),'Abrir missão',pg.K_RETURN,active=True); control((745,558,235,36),'Voltar',pg.K_ESCAPE); return
 if view=='questao':
  m=METAS[meta]; qs=perguntas(meta,s['nivel']); q=qs[qidx]; feitas=eco.respondidas(meta); pr=eco.progresso(meta,s)
  modal(f'Meta {meta+1}: {m[0]}',f'{m[1 if s["nivel"]=="EF" else 2]}  |  Cálculo {qidx+1}/{len(qs)}  |  {len(feitas)}/{len(qs)} acertos registrados')
  barra(115,191,850,len(feitas)/len(qs),'#a7ce90'); bloco('AÇÃO: '+m[3],211,18,'#f4dfad')
  bloco(eco.status_meta(meta,s),247,17,'#bce5ad'); bloco(passos(eco,meta)[0],270,15,'#c6d8cd'); bloco(q[0],297,21)
  resolvida=qidx in feitas
  valor=resposta_texto or (str(q[1]).replace('.',',') if resolvida else '')
  rect((115,366,850,48),'#284f42' if resolvida else '#303030',6); txt(valor+('' if resolvida else '|'),130,376,25)
  if feedback or resolvida:
   ok=resolvida or resposta_ok is True; erro=resposta_ok is False and not resolvida
   rect((115,428,850,106),'#284f42' if ok else '#633c39' if erro else '#303030',8)
   bloco(feedback or 'RESPOSTA CORRETA — já registrada. '+q[2],439,18,'#bce5ad' if ok else '#ffd0c2' if erro else '#e7eef0')
  else: bloco('Digite o número e confirme. Use vírgula para decimais, sem separador de milhar.',442,18)
  label=('Próxima meta' if pr['concluida'] and len(feitas)==len(qs) else 'Ver ação pendente' if len(feitas)==len(qs) else 'Próximo cálculo') if resolvida else 'Confirmar resposta'
  control((112,550,155,40),'Anterior',pg.K_LEFT); control((280,550,155,40),'Revisar próxima',pg.K_RIGHT); control((450,550,300,40),label,pg.K_RETURN,active=True); control((765,550,215,40),'Voltar às metas',pg.K_ESCAPE); return
 if view=='meta_pendente':
  m=METAS[meta]; pr=eco.progresso(meta,s)
  modal(f'Meta {meta+1}: {m[0]}','Cálculos concluídos e salvos')
  bloco(f'RESPOSTAS CORRETAS: {pr["acertos"]}/{pr["total"]}',228,26,'#bce5ad'); barra(115,280,850,1,'#a7ce90')
  bloco('Destino: '+DESTINOS[meta],304,22,'#f4dfad'); bloco(m[3],340,19)
  for j,linha in enumerate(passos(eco,meta)): bloco(linha,405+j*30,18,'#bce5ad')
  bloco('Não repita os cálculos. A conclusão é registrada ao cumprir a ação.',488,17)
  control((115,543,400,46),'Voltar à cidade e realizar ação',pg.K_RETURN,active=True); control((550,543,415,46),'Ver todas as metas',pg.K_ESCAPE); return
 if view=='orcamento':
  modal('Orçamento mensal','Entradas e saídas registradas, incluindo compras de ativos • desde a V4')
  inc=sum(r[1] for r in budget); out=sum(r[2] for r in budget); txt(f'Receitas {brl(inc)}   Despesas {brl(out)}   Resultado {brl(inc-out)}',115,207,20,'#f4dfad',True)
  mx=max([1]+[max(r[1],r[2]) for r in budget]);
  for i,(cat,a,b) in enumerate(budget[budget_page*7:budget_page*7+7]):
   y=252+i*41; txt(cat,115,y,16); rect((385,y,200*a/mx,12),'#82c28e'); rect((385,y+15,200*b/mx,12),'#dd9b85'); txt(brl(a)+'  /  '+brl(b),610,y,16)
  txt('Verde: receitas • coral: despesas',115,567,14,'#b3d0cf'); control((505,552,140,38),'Anterior',pg.K_LEFT); control((657,552,140,38),'Próxima',pg.K_RIGHT); control((810,552,160,38),'Voltar',pg.K_ESCAPE); return
 if view=='ranking':
  modal('Ranking local','Ordenado por metas e XP • quatro perfis independentes')
  rows=[]
  for n in range(1,5):
   f=new_db if n==1 else save/f'cidade_v3_perfil{n}.sqlite3'
   if f.exists():
    en=abrir_save(f); rows.append((len(en.concluidas())+len(en.metas_expansao()),en.estado['xp'],en.estado['nome'] or f'Perfil {n}')); en.db.close()
  for i,(a,b,n) in enumerate(sorted(rows,reverse=True)): bloco(f'{i+1}º     {n}      {a}/21 metas      {b} XP',220+65*i,23)
  control((765,552,200,40),'Voltar',pg.K_ESCAPE); return
 if view=='final':
  modal('Campanha concluída!',f'{len(eco.concluidas())}/15 metas • Dia {s["dia"]} • {s["xp"]} XP')
  bloco(f'Patrimônio financeiro: {brl(eco.patrimonio(s))} | Dívidas: {brl(eco.divida(s))}',225,24,'#f4dfad'); bloco('Você praticou orçamento, consumo consciente, crédito, juros, inflação, investimentos, salários e lucro.',295,23); bloco(f'Minijogos concluídos: {len(eco.minijogos_feitos())}/{len(JOGOS)}',365,19)
  control((115,420,415,50),'Exportar relatório CSV',pg.K_x); control((550,420,415,50),'Continuar explorando',pg.K_ESCAPE); bloco(feedback,505,18)

def draw_distrito(s):
 a,n,sub=ex.AREAS[area_ind]
 if view=='distrito':
  modal('Distrito de patrimônio',f'Expansão opcional • {len(eco.metas_expansao())}/6 objetivos extras • 15 metas originais preservadas')
  txt(f'Carteira {brl(s["saldo"])}   |   Patrimônio ampliado {brl(eco.patrimonio_total(s))}',115,199,19,'#f4dfad',True)
  for i,(k,nome,desc) in enumerate(ex.AREAS):
   x=115+(i%2)*432; y=232+(i//2)*105
   r=pg.Rect(x,y,418,96); rect(r,'#303030',8); screen.blit(distrito_arte[k],(x+7,y+8))
   txt(str(i+1)+'  '+nome,x+169,y+13,19,'#f4dfad',True); txt(desc,x+169,y+40,14); txt('Conquista registrada' if k in eco.metas_expansao() else 'Explorar',x+169,y+66,14,'#bce5ad' if k in eco.metas_expansao() else '#a8c9cc')
   ui_clicks.append((r,pg.K_1+i))
  control((765,555,200,38),'Voltar à cidade',pg.K_ESCAPE); return
 if view=='distrito_area':
  modal(n,sub+' • cálculos obrigatórios antes de cada decisão')
  txt('Carteira: '+brl(s['saldo']),115,204,20,'#bce5ad',True)
  if a=='bolsa':
   txt(f'{s["acoes"]} cotas | {brl(ex.preco(s["dia"]))}/cota | {brl(s["acoes"]*ex.preco(s["dia"]))} em cotas',115,234,17)
   vals=[ex.preco(max(1,s['dia']-7*i)) for i in reversed(range(7))]; pts=[(620+i*53,270-(v-800)*.10) for i,v in enumerate(vals)]
   txt('Preço semanal (R$)',620,195,13); pg.draw.lines(screen,'#8bbf9a',False,pts,3)
   for (xx,yy),v in zip(pts,vals):
    circ('#e9d19a',(xx,yy),3); txt(f'{v/100:g}',xx,yy-13,12,'#e9d19a',False,True)
  elif a=='imobiliaria': txt('Financiamento restante: '+brl(ex.debito(s)),115,234,17)
  elif a=='empresa_nova': txt('Procura extra: '+('3 unidades/dia' if s['empresa_ampliada'] else 'nenhuma'),115,234,17)
  else: screen.blit(distrito_arte[a],(810,195))
  for i,opt in enumerate(ex.opcoes(a,s)):
   y=290+i*78; r=pg.Rect(115,y,850,69); rect(r,'#303030' if opt.habilitada else '#282828',8)
   txt(f'{i+1}  {opt.titulo}',130,y+7,20,'#f4dfad' if opt.habilitada else '#91a19f',True)
   txt(opt.detalhe if opt.habilitada else opt.motivo,130,y+39,16); ui_clicks.append((r,pg.K_1+i))
  if exp_feedback: bloco(exp_feedback,525,15,'#ffd0c2')
  control((765,555,200,38),'Voltar ao distrito',pg.K_ESCAPE); return
 modal(n+' • cálculo',exp_acao.titulo)
 bloco(exp_acao.detalhe,210,18,'#f4dfad'); bloco(exp_acao.pergunta,260,24)
 rect((115,337,850,52),'#303030',7); txt(exp_texto+('|' if not exp_ok else ''),132,350,25)
 if exp_feedback:
  rect((115,405,850,115),'#284f42' if exp_ok else '#633c39',8); bloco(exp_feedback,419,19,'#bce5ad' if exp_ok else '#ffd0c2')
 else: bloco('Digite o resultado e confirme. Nenhum valor é movimentado sem acerto.',420,18)
 control((115,550,410,44),'Continuar' if exp_ok else 'Confirmar resposta',pg.K_RETURN,active=True); control((550,550,415,44),'Voltar',pg.K_ESCAPE)

def distrito_key(e):
 global view,area_ind,exp_acao,exp_texto,exp_feedback,exp_ok
 k=e.key
 if view=='distrito':
  if k in (pg.K_ESCAPE,pg.K_n): view=None
  elif pg.K_1<=k<=pg.K_6: area_ind=k-pg.K_1; exp_feedback=''; view='distrito_area'
 elif view=='distrito_area':
  if k==pg.K_ESCAPE: view='distrito'; exp_feedback=''
  elif pg.K_1<=k<=pg.K_3:
   opts=ex.opcoes(ex.AREAS[area_ind][0],eco.estado); i=k-pg.K_1
   if i<len(opts):
    if not opts[i].habilitada: exp_feedback=opts[i].motivo; return
    exp_acao=opts[i]; exp_texto=''; exp_feedback=''; exp_ok=None; view='distrito_calculo'
 elif view=='distrito_calculo':
  if k==pg.K_ESCAPE or (exp_ok and k in (pg.K_RETURN,pg.K_KP_ENTER)):
   view='distrito_area'; exp_feedback=''; exp_ok=None
  elif not exp_ok:
   if k in (pg.K_RETURN,pg.K_KP_ENTER):
    if not exp_texto.strip(): exp_feedback='Digite sua resposta.'; return
    exp_ok,exp_feedback,xp=eco.agir_expansao(ex.AREAS[area_ind][0],exp_acao.id,exp_texto); beep(exp_ok)
    if exp_ok: exp_feedback+=f' +{xp} XP.' if xp else ' XP já registrado.'
   elif k==pg.K_BACKSPACE: exp_texto=exp_texto[:-1]; exp_feedback=''; exp_ok=None
   elif digito(e): exp_texto=(exp_texto+digito(e))[:18]; exp_feedback=''; exp_ok=None

def iniciar_mini(j):
 global view,mini,mini_etapa,mini_escolhas,mini_texto,mini_feedback,mini_xp
 mini=j; mini_etapa=0; mini_escolhas=set(); mini_texto=''; mini_feedback=''; mini_xp=0; view='mini_jogo'

def draw_mini():
 feitos=eco.minijogos_feitos()
 if view=='mini_lista':
  modal('Circuito financeiro',f'{len(feitos)}/{len(JOGOS)} minijogos concluídos • treino sem alterar carteira ou tempo')
  if not scene:
   for i,(k,nome) in enumerate(LOCAIS.items()):
    x=115+i%2*439; y=208+i//2*109; rect((x,y,420,98),'#303030',9)
    thumb=pg.transform.smoothscale(rooms[k],(112,82)); screen.blit(thumb,(x+8,y+8))
    txt(nome,x+132,y+13,21,'#f4dfad',True); jogos=[j for j in JOGOS if j.local==k]; txt(f'{sum(j.id in feitos for j in jogos)}/{len(jogos)} concluídos',x+132,y+48,16,'#bce5ad')
   txt('Entre em um estabelecimento e pressione G para jogar.',115,551,16); control((795,548,180,42),'Voltar',pg.K_ESCAPE); return
  jogos=[j for j in JOGOS if j.local==scene]
  for i,j in enumerate(jogos):
   y=209+i*110; rect((115,y,855,99),'#303030',10)
   screen.blit(pg.transform.smoothscale(rooms[scene],(105,78)),(126,y+10))
   txt(j.titulo,250,y+10,23,'#f4dfad',True); txt('Concluído • treinar de novo' if j.id in feitos else '2 etapas • +30 XP ao concluir',250,y+43,16,'#bce5ad')
   control((700,y+45,250,38),'Jogar  [ '+str(i+1)+' ]',pg.K_1+i,active=True)
  control((795,548,180,42),'Voltar',pg.K_ESCAPE); return
 modal(mini.titulo,f'{LOCAIS[mini.local]} • '+('1/2  Monte a estratégia' if mini_etapa==0 else '2/2  Faça as contas' if mini_etapa==1 else 'Desafio concluído'))
 if mini_etapa==0:
  bloco(mini.contexto,202,19)
  for i,(nome,valor) in enumerate(mini.cartas):
   x=115+i%2*437; y=282+i//2*83; r=pg.Rect(x,y,420,73); selected=i in mini_escolhas
   rect(r,'#416c59' if selected else '#303030',8); pg.draw.rect(screen,'#e3ba6b' if selected else '#5a7776',r,2,border_radius=8)
   txt((str(i+1)+'  ✓  ' if selected else str(i+1)+'  ')+nome,x+14,y+9,19,'#f5e3b9',True); txt(valor,x+14,y+38,17,'#e5eee4'); ui_clicks.append((r,pg.K_1+i))
  bloco(mini_feedback or (f'Selecione {len(mini.escolha)} '+('carta' if len(mini.escolha)==1 else 'cartas')+' • clique ou use 1–4.'),460,16,'#ffd0c2' if mini_feedback else '#f5d5a0'); bloco(indicador(mini,mini_escolhas),499,17,'#bce5ad')
  control((115,544,270,43),'Voltar',pg.K_ESCAPE); control((600,544,370,43),'Confirmar estratégia',pg.K_RETURN,active=True)
 elif mini_etapa==1:
  bloco('ESTRATÉGIA CORRETA! Agora calcule o resultado.',196,17,'#bce5ad'); bloco(mini.pergunta,221,24,'#f4dfad')
  for i in sorted(mini_escolhas): txt(mini.cartas[i][0]+'  •  '+mini.cartas[i][1],117,279+26*sorted(mini_escolhas).index(i),17,'#bce5ad')
  rect((115,350,855,58),'#303030',7); txt('R$  '+mini_texto+'|',134,363,28,'#f4efd9',True)
  
  if mini_feedback: rect((115,420,855,83),'#633c39',8)
  bloco(mini_feedback or 'Digite o resultado e confirme. Use vírgula ou ponto para decimais.',433,18,'#ffd0c2' if mini_feedback else '#e7eef0')
  control((115,544,270,43),'Rever estratégia',pg.K_ESCAPE); control((600,544,370,43),'Confirmar cálculo',pg.K_RETURN,active=True)
 else:
  bloco('RESPOSTA CORRETA! Estratégia e cálculo corretos.',225,26,'#bce5ad'); bloco(mini.explicacao,294,23,'#f4dfad'); bloco(f'+{mini_xp} XP • {len(feitos)}/{len(JOGOS)} minijogos completos' if mini_xp else 'Treino repetido: sem XP extra.',390,23,'#bce5ad'); bloco('O XP foi salvo. Para avançar nas 15 metas, resolva os cálculos da campanha.',446,18)
  control((115,544,240,43),'Outros minijogos',pg.K_RETURN); control((370,544,300,43),'Calcular meta atual [F]',pg.K_f,active=True); control((685,544,285,43),'Voltar ao estabelecimento',pg.K_ESCAPE)

def indice_tecla(k):
 for i in range(4):
  if k in (getattr(pg,'K_'+str(i+1)),getattr(pg,'K_KP'+str(i+1),-1)): return i
 return None

def mini_key(e):
 global view,mini_etapa,mini_texto,mini_feedback,mini_xp,mini_escolhas
 k=e.key
 idx=indice_tecla(k)
 if view=='mini_lista':
  if k in (pg.K_ESCAPE,pg.K_g): view=None
  elif scene and idx in (0,1,2): iniciar_mini([j for j in JOGOS if j.local==scene][idx])
  return
 if mini_etapa==0:
  if k==pg.K_ESCAPE: view='mini_lista'
  elif idx is not None:
   mini_escolhas,mini_feedback=selecionar(mini,mini_escolhas,idx)
  elif k in (pg.K_RETURN,pg.K_KP_ENTER):
   if escolha_correta(mini,mini_escolhas): mini_etapa=1; mini_feedback=''; mini_texto=''; beep(True)
   else: mini_feedback='REVISE: '+erro_estrategia(mini,mini_escolhas); beep(False)
 elif mini_etapa==1:
  if k==pg.K_ESCAPE: mini_etapa=0; mini_feedback=''
  elif k in (pg.K_RETURN,pg.K_KP_ENTER):
   if not mini_texto.strip(): mini_feedback='Digite o resultado antes de confirmar.'; return
   ok,mini_xp=eco.concluir_minijogo(mini.id,mini_escolhas,mini_texto); beep(ok)
   if ok: mini_etapa=2; mini_feedback=''
   else: mini_feedback='RESPOSTA INCORRETA. '+DICA_CALCULO[mini.id]
  elif k==pg.K_BACKSPACE: mini_texto=mini_texto[:-1]; mini_feedback=''
  elif digito(e): mini_texto=(mini_texto+digito(e))[:18]; mini_feedback=''
 elif k in (pg.K_RETURN,pg.K_KP_ENTER): view='mini_lista'
 elif k==pg.K_f: abrir_meta_atual(True)
 elif k==pg.K_ESCAPE: view=None

def abrir_questao(i):
 global view,meta,qidx,resposta_texto,feedback,resposta_ok
 meta=i; qidx=primeiro_calculo(eco,i); resposta_texto=''; feedback=''; resposta_ok=None
 view='meta_pendente' if not pendentes(eco,i) and not eco.progresso(i)['concluida'] else 'questao'

def abrir_meta_atual(direto=False):
 global view,meta
 i=proxima_meta(eco); meta=0 if i is None else i
 if direto and i is not None: abrir_questao(i)
 else: view='metas'

def digito(e):
 t=getattr(e,'unicode','')
 if t and t in '0123456789.,-': return t
 for i in range(10):
  if e.key==getattr(pg,'K_KP'+str(i),-1): return str(i)
 if e.key==pg.K_KP_PERIOD: return ','
 return ''

def acionar_overlay(e):
 # All queued clicks on the same selection screen must be processed. On a
 # transition, old buttons are invalid until the next frame renders them.
 def estado_botoes():
  return (view,mini_etapa,mini.id if mini else None,meta,qidx,bool(resposta_ok),bonus_result is not None,desafio is not None,perfil,area_ind,exp_acao.id if exp_acao else None,exp_ok)
 antes=estado_botoes()
 overlay_key(e)
 if estado_botoes()!=antes: ui_clicks.clear()

PAINEIS={pg.K_F3:'financas',pg.K_F4:'inventario',pg.K_F5:'ranking_cidade',pg.K_F6:'credito',pg.K_F7:'emprestimos',pg.K_F8:'investir',pg.K_F9:'quiosque',pg.K_F10:'carreira',pg.K_F12:'conquistas'}
def abrir_personagem(retorno='inicio'):
 global view,nome_edicao,tipo_edicao,feedback,perfil_retorno
 s=eco.estado; nome_edicao=s['nome']; tipo_edicao=s['personagem']; feedback=''; perfil_retorno=retorno; view='personagem'

def iniciar_partida():
 global view
 if not eco.estado['tutorial']:
  with eco.db: eco.db.execute('UPDATE jogador SET tutorial=1')
  view='tutorial'
 else: view=None

def draw_painel_extra(s):
 titles={'financas':'Minhas finanças','inventario':'Inventário','credito':'Cartão de crédito','emprestimos':'Empréstimos','investir':'Investimentos','quiosque':'Meu quiosque','carreira':'Minha carreira','conquistas':'Conquistas','ranking_cidade':'Ranking local'}
 if view=='ranking_cidade':
  modal('Ranking local','Quatro perfis • ordenado por metas e XP')
  rows=[]
  for n in range(1,5):
   f=new_db if n==1 else save/f'cidade_v3_perfil{n}.sqlite3'
   if f.exists():
    en=abrir_save(f); es=en.estado; rows.append((len(en.concluidas())+len(en.metas_expansao()),es['xp'],es['nome'] or f'Perfil {n}',n)); en.db.close()
  for i,(a,b,n,_) in enumerate(sorted(rows,reverse=True)): bloco(f'{i+1}º    {n}   •   {a}/21 metas   •   {b} XP',220+65*i,23)
 else:
  modal(titles[view],s['nome'] or 'Seu personagem')
  yes=lambda k:'Adquirido' if s[k] else 'Ainda não adquirido'
  data={
   'financas':[('Carteira',brl(s['saldo'])),('Reserva',brl(s['reserva'])),('Patrimônio ampliado',brl(eco.patrimonio_total(s))),('Dívidas totais',brl(eco.divida(s)))],
   'inventario':[('Bicicleta',yes('bicicleta')),('Notebook',yes('notebook')),('Móveis',yes('moveis')),('Imóvel',yes('imovel')),('Carro',yes('carro')),('Roupa extra',yes('roupa'))],
   'credito':[('Fatura',brl(s['cartao'])),('Destino','Banco: consulte as opções de cartão')],
   'emprestimos':[('Empréstimo',brl(s['emprestimo'])),('Financiamento do imóvel',brl(ex.debito(s))),('Destino','Banco: consulte as opções de empréstimo')],
   'investir':[('Reserva',brl(s['reserva'])),('CDB',brl(s['cdb'])),('Cotas fictícias',str(s['acoes'])),('Valor das cotas',brl(s['acoes']*ex.preco(s['dia'])))],
   'quiosque':[('Negócio','Aberto' if s['negocio'] else 'Ainda fechado'),('Estoque',str(s['estoque'])),('Receita',brl(s['receita'])),('Resultado acumulado',brl(s['lucro']))],
   'carreira':[('Profissão',s['profissao'] or 'Ainda não contratado'),('Horas acumuladas',str(s['horas_total'])),('Salários',brl(s['salarios'])),('Promoções',str(s['promocao']))],
   'conquistas':[('Campanha',f'{len(eco.concluidas())}/15'),('Patrimônio',f'{len(eco.metas_expansao())}/6'),('Minijogos',f'{len(eco.minijogos_feitos())}/{len(JOGOS)}'),('Experiência',f'{s["xp"]} XP')]}[view]
  for i,(label,value) in enumerate(data):
   x=115+(i%2)*435; y=210+(i//2)*97; rect((x,y,412,84),'#292929',8); txt(label,x+13,y+9,16,'#d4c6a7',True); fit_text(value,x+13,y+35,385,25,'#ffffff',True)
  if view=='financas': control((115,548,260,43),'Orçamento',pg.K_o); control((390,548,260,43),'Extrato',pg.K_TAB)
  elif view=='conquistas': control((115,548,260,43),'Missões',pg.K_m); control((390,548,260,43),'Distrito',pg.K_n)
  elif view in ('investir','quiosque','inventario'): control((115,548,260,43),'Distrito de patrimônio',pg.K_n)
 control((765,548,200,43),'Voltar',pg.K_ESCAPE)

def overlay_key(e):
 global view,meta,qidx,resposta_texto,feedback,desafio,bonus_text,contraste,mudo,budget_page,running,resposta_ok,bonus_result
 k=e.key
 global nome_edicao,tipo_edicao,budget,showlog
 if view=='personagem':
  if k==pg.K_ESCAPE: view=perfil_retorno; feedback=''
  elif k in (-300,-301): tipo_edicao='homem' if k==-300 else 'mulher'
  elif k in (pg.K_RETURN,pg.K_KP_ENTER):
   if eco.personalizar(nome_edicao,tipo_edicao):
    feedback=''; iniciar_partida() if perfil_retorno=='inicio' else None
    if perfil_retorno!='inicio': view=perfil_retorno
   else: feedback='Digite um nome válido (1 a 24 caracteres).'
  elif k==pg.K_BACKSPACE: nome_edicao=nome_edicao[:-1]
  else:
   u=getattr(e,'unicode','')
   if u and all(c.isalnum() or c in " -'" for c in u): nome_edicao=(nome_edicao+u)[:24]
  return
 if view in PAINEIS.values():
  if k==pg.K_ESCAPE: view=None
  elif k==pg.K_o: budget=eco.orcamento(); budget_page=0; view='orcamento'
  elif k==pg.K_TAB: view=None; showlog=True
  elif k==pg.K_m: abrir_meta_atual()
  elif k==pg.K_n: view='distrito'
  return
 if view in ('distrito','distrito_area','distrito_calculo'):
  distrito_key(e); return
 if view in ('mini_lista','mini_jogo'):
  mini_key(e); return
 if desafio:
  if k in (pg.K_RETURN,pg.K_KP_ENTER):
   key,q=desafio
   if bonus_result is not None:
    desafio=None; bonus_result=None; run(key)
   elif not bonus_text.strip(): feedback='Digite uma resposta antes de confirmar.'
   else:
    ok=correto(bonus_text,q[1]); awarded=eco.bonus(key,ok); beep(ok); bonus_result=ok
    feedback=('RESPOSTA CORRETA! '+('+10 XP. ' if awarded else 'XP já recebido. ') if ok else 'RESPOSTA INCORRETA. ')+q[2]
  elif k==pg.K_s and bonus_result is None:
   key,q=desafio; desafio=None; bonus_result=None; run(key)
  elif k==pg.K_ESCAPE:
   desafio=None; bonus_result=None
  elif bonus_result is None and k==pg.K_BACKSPACE: bonus_text=bonus_text[:-1]; feedback=''
  elif bonus_result is None and digito(e): bonus_text=(bonus_text+digito(e))[:18]; feedback=''
  return
 if view in ('inicio','pausa'):
  if k in (pg.K_RETURN,pg.K_ESCAPE):
   if not eco.estado['nome']: abrir_personagem('inicio')
   else: iniciar_partida()
  elif k==pg.K_j: abrir_personagem(view)
  elif k==pg.K_e or k==pg.K_h: feedback='Dificuldade alterada.' if eco.nivel('EF' if k==pg.K_e else 'EM') else 'Nível bloqueado após responder.'
  elif pg.K_1<=k<=pg.K_4: trocar_perfil(k-pg.K_1+1)
  elif k==pg.K_t: view='tutorial'
  elif k==pg.K_r: view='ranking'
  elif k==pg.K_c: contraste=not contraste
  elif k==pg.K_s: mudo=not mudo; musica()
  elif k==pg.K_q: running=False
  elif k==pg.K_x: feedback='CSV em '+str(eco.exportar(save/f'exportacao_perfil{perfil}'))
 elif view=='aprendi':
  if k in (pg.K_ESCAPE,pg.K_RETURN,pg.K_l): view=None
 elif view in ('tutorial','ranking'):
  if k in (pg.K_RETURN,pg.K_ESCAPE): view=None if view=='tutorial' else 'pausa'
 elif view=='metas':
  if k==pg.K_ESCAPE or k==pg.K_m: view=None
  elif -1014<=k<=-1000:
   meta=-1000-k; abrir_questao(meta)
  elif k==pg.K_UP: meta=max(0,meta-1)
  elif k==pg.K_DOWN: meta=min(14,meta+1)
  elif k in (pg.K_RETURN,pg.K_KP_ENTER): abrir_questao(meta)
 elif view=='questao':
  if k==pg.K_ESCAPE: view='metas'
  elif k in (pg.K_LEFT,pg.K_RIGHT):
   qidx=(qidx+(1 if k==pg.K_RIGHT else -1))%len(perguntas(meta,eco.estado['nivel'])); resposta_texto=''; feedback=''; resposta_ok=None
  elif k in (pg.K_RETURN,pg.K_KP_ENTER):
   if qidx in eco.respondidas(meta):
    view,meta,qidx=continuar(eco,meta,qidx); resposta_texto=''; feedback=''; resposta_ok=None
   else:
    resposta_ok,feedback=confirmar(eco,meta,qidx,resposta_texto); beep(resposta_ok)
  elif qidx not in eco.respondidas(meta):
   if k==pg.K_BACKSPACE: resposta_texto=resposta_texto[:-1]; feedback=''; resposta_ok=None
   elif digito(e): resposta_texto=(resposta_texto+digito(e))[:18]; feedback=''; resposta_ok=None
 elif view=='meta_pendente':
  if k in (pg.K_RETURN,pg.K_KP_ENTER): view=None
  elif k==pg.K_ESCAPE: view='metas'
 elif view=='orcamento':
  if k in (pg.K_ESCAPE,pg.K_o): view=None
  elif k==pg.K_RIGHT: budget_page=min(max(0,(len(budget)-1)//7),budget_page+1)
  elif k==pg.K_LEFT: budget_page=max(0,budget_page-1)
 elif view=='final':
  if k==pg.K_ESCAPE: view=None
  elif k==pg.K_x: feedback='CSV em '+str(eco.exportar(save/f'exportacao_perfil{perfil}'))

running=True
if __name__=='__main__':
 if '--smoke' in sys.argv:
  for v in ('inicio','personagem','financas','inventario','credito','emprestimos','investir','quiosque','carreira','conquistas','ranking_cidade','tutorial','aprendi','metas','questao','orcamento','ranking','final','pausa','distrito',None):
   view=v; frame(.016)
  # Isolated save is required; verify feedback and progression via the actual key handler.
  if os.getenv('CIDADE_SAVE_DIR'):
   eco.reset(); abrir_personagem(); frame(.016)
   acionar_overlay(pg.event.Event(pg.KEYDOWN,key=-301,unicode='')); assert tipo_edicao=='mulher'
   for c in 'Ana': acionar_overlay(pg.event.Event(pg.KEYDOWN,key=pg.K_a,unicode=c))
   acionar_overlay(pg.event.Event(pg.KEYDOWN,key=pg.K_RETURN,unicode='')); assert eco.estado['nome']=='Ana' and eco.estado['personagem']=='mulher'
   abrir_questao(0)
   def key(k,u=''): overlay_key(pg.event.Event(pg.KEYDOWN,key=k,unicode=u))
   key(pg.K_0,'0'); key(pg.K_RETURN); assert resposta_ok is False and 'INCORRETA' in feedback; frame(.016)
   key(pg.K_BACKSPACE); key(pg.K_KP2); key(pg.K_KP2); key(pg.K_KP0); key(pg.K_RETURN); assert resposta_ok and 'CORRETA' in feedback and eco.respondidas(0)=={0}; frame(.016)
   key(pg.K_RETURN); assert qidx==1
   for num in ('520','75'):
    for c in num: key(getattr(pg,'K_'+c),c)
    key(pg.K_RETURN); assert resposta_ok; frame(.016); key(pg.K_RETURN)
   assert view=='meta_pendente'; frame(.016); key(pg.K_RETURN); assert view is None
   for k in ('cargo:Atendente','turno4','turno4'): assert eco.agir('empresa',k)[0]
   assert 0 in eco.concluidas(); abrir_meta_atual(True); assert meta==1 and qidx==0; frame(.016)
   enter_room('loja'); decidir('prazo'); bonus_text='0'; key(pg.K_RETURN); assert bonus_result is False and desafio and 'INCORRETA' in feedback; frame(.016); key(pg.K_ESCAPE); assert not desafio
   decidir('prazo'); bonus_text='440'; key(pg.K_RETURN); assert bonus_result is True and desafio and 'CORRETA' in feedback; frame(.016); key(pg.K_ESCAPE); assert not desafio
   leave_room(); view=None
  # Drive the real mouse event queue. Both clicks on a double-selection
  # strategy must be processed before the same frame is drawn again.
  def click_at(x,y):
   ww,hh=window.get_size(); sc=min(ww/W,hh/H)
   pg.event.post(pg.event.Event(pg.MOUSEBUTTONDOWN,button=1,pos=(int((ww-W*sc)/2+x*sc),int((hh-H*sc)/2+y*sc))))
  def post_key(k,u=''): pg.event.post(pg.event.Event(pg.KEYDOWN,key=k,unicode=u))
  for k in places:
   enter_room(k); talking=True; frame(.016); talking=False; view='mini_lista'; frame(.016)
   for n,j in enumerate([j for j in JOGOS if j.local==k]):
    click_at(800,270+n*110); frame(.016); assert view=='mini_jogo' and mini==j
    click_at(800,565); frame(.016); assert mini_etapa==0 and mini_feedback.startswith('REVISE')
    for i in reversed(j.escolha): click_at(200+i%2*437,312+i//2*83)
    click_at(800,565); frame(.016); assert mini_etapa==1 and mini_escolhas==set(j.escolha),(j.id,mini_escolhas)
    post_key(pg.K_KP0); click_at(800,565); frame(.016); assert mini_etapa==1 and 'INCORRETA' in mini_feedback
    post_key(pg.K_BACKSPACE)
    for c in j.resposta: post_key(pg.K_KP_PERIOD if c=='.' else getattr(pg,'K_KP'+c))
    click_at(800,565); frame(.016); assert mini_etapa==2 and j.id in eco.minijogos_feitos()
    click_at(230,565); frame(.016); assert view=='mini_lista'
   view=None
  leave_room(); view='mini_lista'; frame(.016)
  # Test the actual new overlay and click routing with isolated save.
  if os.getenv('CIDADE_SAVE_DIR'):
   view=None; frame(.016); click_at(72,566); frame(.016); frame(.016); assert view=='distrito'
   click_at(300,275); frame(.016); assert view=='distrito_area' and area_ind==0
   click_at(500,315); frame(.016); assert view=='distrito_calculo'
   post_key(pg.K_KP0); click_at(320,570); frame(.016); assert exp_ok is False and 'INCORRETA' in exp_feedback
   post_key(pg.K_BACKSPACE)
   for c in '680': post_key(getattr(pg,'K_KP'+c))
   # Need sufficient funds; fixture changes only isolated smoke database.
   with eco.db: eco.db.execute('UPDATE jogador SET saldo=200000')
   click_at(320,570); frame(.016); assert exp_ok and eco.estado['notebook']==1
   click_at(320,570); frame(.016); assert view=='distrito_area'
  print('SMOKE OK')
 else:
  musica()
  while running: frame(min(clock.tick(60)/1000,.04))
 pg.quit(); eco.db.close()
